# Domain Brain — Architecture & Integration with GitHub Copilot / VS Code

## What this is

A canonical, versioned domain knowledge base that Copilot agents in VS
Code read on demand — distinct from the memory tool covered in the
earlier demo. Memory is per-tool, per-person recall; this is shared,
authored, PR-reviewed source of truth that AI, BA, Dev, and QA all read
and write to.

## Why not just use agent memory for this

The local memory tool (`/memories/repo/`) is workspace-local and
per-machine. A BA or QA engineer's Copilot Studio agent has no access to
what a developer's VS Code memory has learned. Domain knowledge needs to
outlive any one person's memory files and be reviewable — so it's
authored as plain files in the repo, not accumulated as memory.

## How it connects to VS Code / GitHub Copilot

1. `.github/copilot-instructions.md` acts as the pointer — it tells the
   agent which `domain-knowledge/*.md` file to read based on what the
   task touches, rather than loading everything into context every time.
2. The local memory tool still has a role: session/user memory for
   personal preferences, and repo memory for things like "we always
   apply requireAuth" (tactical, code-level habits). Domain *meaning*
   (why requireAuth exists, which entities it protects) belongs in
   `domain-knowledge/`, not memory — memory is not PR-reviewed or
   visible to other teams.
3. When an agent surfaces a new domain fact mid-conversation, the
   instructions direct it to propose an addition to the relevant file
   rather than just remembering it locally — this is what keeps the
   brain from fragmenting across individual developers' memory stores.

## Ownership model

| File | Owner | Feeds from |
|---|---|---|
| `glossary.md` | BA | Requirements docs, stakeholder conversations |
| `business-rules.md` | BA | Policy decisions, requirement docs |
| `workflows.md` | BA | Process design, requirement docs |
| `data-model.md` | Dev | Schema/migrations (link to source of truth) |
| `edge-cases.md` | QA | Defects and test findings — the feedback loop |
| `compliance-constraints.md` | Governance | Regulatory/policy sources |

Changes go through a PR like any code change. Each file's owner is the
required reviewer for changes to that file.

## Rollout sequencing

1. **Seed the glossary and top 10 business rules.** Nothing else is
   useful until shared vocabulary exists — this is the dependency root.
2. **Wire the `.github/copilot-instructions.md` pointer** into an actual
   dev repo and confirm agents read it (lowest governance risk, fastest
   feedback — dev/QA only, nothing customer- or employee-facing yet).
3. **Start the QA feedback loop**: any defect that reveals a domain
   behavior gets an `edge-cases.md` entry as part of ticket closure, not
   as an afterthought.
4. **Extend to Copilot Studio KB agents** (BA/AI-facing) once the dev-side
   loop is stable — this is higher governance risk since those agents may
   be employee- or customer-facing, so route it through the same
   audit-approved gate used for AskHR before it goes live.
5. **Set a review cadence** per file (see ownership table) and decide
   whether domain-brain changes need the same intake review as new agent
   launches, or a lighter one — a governance decision, not a technical one.

## Open decisions to confirm before wide rollout

- Staleness policy: how old can an entry get before it's flagged for
  re-certification?
- Does a domain-knowledge PR require sign-off from more than one team
  when it touches shared entities (e.g. Order touches BA, Dev, and QA)?
- Should `compliance-constraints.md` changes route through the
  Governance Gate intake process by default?
