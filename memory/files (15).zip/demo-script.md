# Demo: Memory in GitHub Copilot / VS Code Agents

**Audience:** QA automation + functional QA team
**Runtime:** ~15 minutes + discussion
**Scaffold:** `copilot-memory-demo/` (this repo)

## Purpose

Show, live, the difference between an agent with no persistent context and
one using VS Code's memory tool — then connect that to the org-level
Copilot Memory system, since enabling that is a governance decision, not
just a dev setting.

## Prerequisites (set up before the room fills)

- VS Code (Stable is fine; Insiders if you want to show newest UI) with
  GitHub Copilot Chat installed and signed in
- Setting `chat.tools.memory.enabled` — confirm it's `true` (default on)
- This scaffold opened as its own workspace folder
- Run **Chat: Clear All Memory Files** once beforehand so the demo starts
  from a clean slate

## Table to have on screen for the wrap-up

| Scope | Path | Persists across sessions | Persists across workspaces | Use for |
|---|---|---|---|---|
| User | `/memories/` | Yes | Yes | Personal preferences, habits |
| Repository | `/memories/repo/` | Yes | No | Codebase conventions, build commands |
| Session | `/memories/session/` | No | No | In-progress plan, task-specific notes |
| Copilot Memory | GitHub-hosted | Yes (28-day expiry) | N/A (repo-scoped) | Cross-surface repo knowledge (coding agent, code review, CLI) |

---

## Act 1 — The problem (2 min)

**Talking point:** "Every new chat starts blank unless we've taught the
agent something. Watch."

**Type in Chat:**
```
What conventions does this project follow for API endpoints?
```

**Expected:** The agent either says it doesn't know, or infers only from
reading `orders.js` directly — it has no stored knowledge of the auth
convention, because nothing has taught it yet.

---

## Act 2 — Teach repository memory (4 min)

**Talking point:** "Now I'll teach it a convention the way I'd tell a new
teammate."

**Type in Chat:**
```
Remember that every API endpoint in this project must use the requireAuth
middleware, and that we use conventional commits for all commit messages.
```

**Expected:** Agent confirms and writes a repository-scoped memory file.

**Show it:** Run command **Chat: Show Memory Files** → open the new file
under Repository. Point out this is stored locally, scoped to this
workspace only.

---

## Act 3 — Recall in a new conversation (3 min)

**Talking point:** "Same workspace, brand new chat — no re-explaining."

Start a **new chat session** (not a new workspace).

**Type in Chat:**
```
Add a new endpoint GET /api/orders to src/api/orders.js that returns a
list of orders.
```

**Expected:** The generated route includes `requireAuth` without being
told again — this is the payoff moment. Pause here; this is the one to
let land.

---

## Act 4 — User memory across workspaces (3 min)

**Talking point:** "Repository memory stayed in this project. User memory
follows you everywhere."

**Type in Chat:**
```
Remember that I prefer arrow functions over function declarations in
JavaScript.
```

Open a **different, unrelated folder** as a new workspace (any scratch
folder works). Ask the agent to write a small function.

**Expected:** It uses an arrow function, in a workspace that has never
seen this scaffold — demonstrating the scope difference from Act 2/3.

---

## Act 5 — Session memory (2 min, optional)

**Talking point:** "Not everything should stick around. Plans are a good
example."

Switch to Plan mode, ask the agent to plan a small multi-step change.
Show the `plan.md` it creates via **Chat: Show Memory Files** under
Session. Close the chat and start a new one — the plan is gone. Session
memory is intentionally disposable.

---

## Act 6 — Copilot Memory and the governance angle (3 min)

**Talking point — shift from "how it works" to "what we'd need to decide
before turning this on org-wide":**

- Copilot Memory is GitHub-hosted, **off by default**, and shares
  memories across coding agent, code review, and CLI — not just VS Code.
- Memories auto-expire after 28 days and are verified against the
  codebase before being applied, but they're still a remote store of
  insights about our repos.
- Enabling it is an org/enterprise policy decision, not an individual
  toggle — repo owners can review and delete stored memories under
  Repository Settings.

**Discussion prompts for the room:**
1. Of the two facts we just taught (auth middleware, commit style),
   which would you want scoped to this repo only vs. pushed to
   Copilot Memory for cross-surface reuse?
2. Who should hold the authority to enable Copilot Memory at the
   repo or org level?
3. What's our review cadence for repo owners auditing stored memories?

---

## Wrap-up

Return to the scope table above. One-line summary: **local memory tool
for personal/session-in-VS-Code, Copilot Memory for shared repo
knowledge across the whole Copilot ecosystem — and the second one is a
governance decision, not a dev setting.**

## Facilitator notes

- Reset between runs with **Chat: Clear All Memory Files**.
- If recall doesn't happen in Act 3, check `chat.tools.memory.enabled`.
- Individual memory file deletion isn't supported yet — only clear-all.
- If someone asks about retention/privacy: local scopes never leave the
  machine; Copilot Memory is repo-scoped, write-access-gated, and
  auto-expires in 28 days.
