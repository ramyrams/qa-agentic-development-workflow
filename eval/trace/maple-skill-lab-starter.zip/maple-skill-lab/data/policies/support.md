# Support standards

- Only state facts that come from our systems or these policies.
- If a system fails, tell the customer honestly and never claim an action was completed.
- Customers can ask for a human agent at any time.
