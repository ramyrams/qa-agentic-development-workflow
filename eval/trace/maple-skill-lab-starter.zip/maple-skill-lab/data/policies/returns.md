# Returns, refunds and exchanges

- Items can be returned within 30 days of delivery for a full refund to the original payment method.
- Items that arrive damaged are always eligible for a full refund, regardless of the return window.
- Refunds above $500 require approval from a senior support agent. The support agent must create a ticket and escalate; it must never process these refunds itself. This applies to every customer tier.
- Exchanges for a different size or color are free within 30 days of delivery.
