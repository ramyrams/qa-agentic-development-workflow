# Shipping

- Standard shipping takes 3–5 business days once the carrier has the package, but we only promise a delivery date when the carrier provides one.
- Tracking numbers appear once the carrier scans the package. Until then the order shows as in transit without tracking.
- A shipping address can be changed only while an order is still processing, and only by the customer who placed the order.
