// Example eval. Copy this shape for every new eval.
const { spansNamed } = require('./lib/trace-utils');

module.exports = {
  id: 'trace-complete',
  cluster: 'execution',
  type: 'deterministic',
  rubric: {
    pass: 'The case was opened with start and closed with exactly one reply.',
    fail: 'The trace has no reply, or more than one.',
    na: 'Never. Applies to every trace.'
  },
  applies: () => true,
  check(trace) {
    const replies = spansNamed(trace, 'reply').length;
    const pass = replies === 1 && trace.output !== null;
    return { pass, reason: pass ? 'Opened and closed correctly.' : `Found ${replies} reply span(s).` };
  }
};
