// Cheap flagging rules, no model involved. Add more.
module.exports = [
  { id: 'tool-error', label: 'A tool call returned an error', test: t => t.totals.tool_errors > 0 }
];
