const fs = require('fs');
const path = require('path');
const loadEvals = () => fs.readdirSync(__dirname).filter(f => f.endsWith('.eval.js')).sort().map(f => require(path.join(__dirname, f)));
module.exports = { loadEvals };
