// Regression suite for the skill. A skill can't be re-run from npm (Copilot runs it),
// so this suite checks two things for every golden case:
//   1. the trace was produced by the CURRENT SKILL.md (otherwise: re-run the case), and
//   2. every eval passes on it.
const { test } = require('node:test');
const assert = require('node:assert');
const { loadTraces } = require('../scripts/load-traces');
const { loadEvals } = require('../evals/load-evals');
const { skillHash } = require('../scripts/skill-hash');
const golden = require('../data/golden.json');

const traces = loadTraces();
const evals = loadEvals();
const current = skillHash();

for (const id of golden.cases) {
  test(id, () => {
    const t = traces.find(x => x.trace_id === id);
    assert.ok(t, `No trace for ${id}. Run the case with the Maple Support agent.`);
    assert.strictEqual(t.skill_hash, current, `${id} was run with skill ${t.skill_hash}, but SKILL.md is now ${current}. Re-run the case.`);
    const failures = evals.filter(e => e.applies(t)).map(e => ({ id: e.id, r: e.check(t) })).filter(x => !x.r.pass);
    assert.deepStrictEqual(failures.map(f => `${f.id}: ${f.r.reason}`), [], `Evals failed for ${id}`);
  });
}
