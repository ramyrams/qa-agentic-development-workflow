# Maple skill lab: traces and evals for a Copilot agent skill

The system under test is a real GitHub Copilot custom agent (`Maple Support`) and its skill (`.github/skills/maple-support/SKILL.md`). You run support cases through it in VS Code with Claude Sonnet 5. Every tool call is recorded to `runs/<case>.trace.json`. You then read the traces, find failure patterns, write evals, fix the skill, and prove the fix with a regression suite.

No API keys and no dependencies: Node.js 20+ and GitHub Copilot in VS Code.

## Quick start
1. Open this folder in VS Code. In Copilot Chat choose Agent mode and Claude Sonnet 5.
2. Run `/run-cases` in chat (it uses the Maple Support agent). Approve the terminal commands.
3. In the terminal:
```
npm run list          # one line per case
npm run view -- C-06  # one trace, span by span
npm run evals         # score traces
npm test              # regression suite
```
No Copilot access yet? Copy the recorded run into place with `cp samples/reference-v1-runs/*.json runs/` and continue from there.

## How the pieces fit
- `cases/` customer cases, `data/` orders, customers and policies (the definition of correct).
- `.github/skills/maple-support/scripts/maple.js` the only way the agent acts. It records every call as a span.
- `evals/`, `scripts/`, `tests/`, `review/` the evaluation side, plus the Trace Investigator, eval-writer and skill-fixer agents.
- `npm test` fails on any golden case whose trace was produced by an older version of SKILL.md, so every skill change forces a re-run.
