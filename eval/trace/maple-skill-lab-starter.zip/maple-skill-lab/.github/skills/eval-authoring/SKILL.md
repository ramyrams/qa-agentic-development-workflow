---
name: eval-authoring
description: How to write an eval for the Maple Support traces - rubric first, the lightest evaluator that works, the repo's eval file shape, and validation against real traces. Use whenever creating or changing a file in evals/.
---
# Eval authoring

## 1. Rubric first
Fill in [templates/rubric.template.md](templates/rubric.template.md) before writing code: pass, fail and N/A, each observable in the trace.

## 2. Choose the evaluator
| Choose | When |
|---|---|
| Deterministic | The failure shows in structured span data: tool names, arguments, status, counts, amounts, IDs, dates. |
| Binary classifier | A yes/no label on free text that rules can't read reliably, e.g. "does the reply claim success?" |
| LLM judge | The check needs reasoning, e.g. "is the reply faithful to the policy?" |

Prefer deterministic: it's cheap, fast and repeatable. A regex over the reply is a reasonable stand-in for a classifier in this lab; note it as a known weak spot.

## 3. Write the file
Copy [templates/eval.template.js](templates/eval.template.js) to `evals/<id>.eval.js`. Take business rules from `data/policies/`, never from `SKILL.md`.

## 4. Validate
Run `npm run evals -- --verbose`. Every case in the cluster should fail; no other case should. Open any surprise: it's either a new finding or a false positive.

## 5. Protect it
Add one failing case ID to `data/golden.json` and run `npm test`. It should fail until the skill is fixed and the case is re-run.
