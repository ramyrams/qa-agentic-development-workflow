## Eval: <id>
- **Cluster / category:** <name> / <context | decision | execution | trajectory/cost>
- **Source cases:** <C-xx>
- **Business rule (source):** <rule> - data/policies/<file>.md
- **Pass:** <observable condition>
- **Fail:** <observable condition>
- **N/A:** <when it doesn't apply>
- **Evaluator:** <deterministic | classifier | LLM judge>, because <one sentence>
