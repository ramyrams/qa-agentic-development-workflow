const { toolSpans, spansNamed, firstOutput, reply, toolOutputText } = require('./lib/trace-utils');

module.exports = {
  id: 'EVAL-ID',
  cluster: 'context', // context | decision | execution | trajectory
  type: 'deterministic', // deterministic | classifier | llm-judge
  rubric: { pass: 'PASS CONDITION', fail: 'FAIL CONDITION', na: 'WHEN IT DOES NOT APPLY' },
  applies(trace) { return true; },
  check(trace) {
    const pass = true;
    return { pass, reason: pass ? 'WHY IT PASSED' : 'WHAT WENT WRONG' };
  }
};
