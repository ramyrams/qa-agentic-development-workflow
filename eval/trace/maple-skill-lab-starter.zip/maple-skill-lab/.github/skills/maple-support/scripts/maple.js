#!/usr/bin/env node
// Maple support tool script. Every call is recorded as a span in runs/<case>.trace.json,
// so each case the agent handles leaves a complete trace behind. No dependencies.
//
//   node .github/skills/maple-support/scripts/maple.js <command> --case C-01 [--flag value ...]
//
// Commands: start, lookup_order, get_customer, check_return, search_policy, refund,
//           create_ticket, escalate, update_address, note, reply
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.resolve(__dirname, '..', '..', '..', '..');
const SKILL_FILE = path.resolve(__dirname, '..', 'SKILL.md');
const TODAY = '2026-09-25';
const read = p => JSON.parse(fs.readFileSync(path.join(ROOT, p), 'utf8'));

// ---- args ----
const [command, ...rest] = process.argv.slice(2);
const args = {};
for (let i = 0; i < rest.length; i++) {
  if (rest[i].startsWith('--')) {
    const k = rest[i].slice(2);
    const v = rest[i + 1] && !rest[i + 1].startsWith('--') ? rest[++i] : true;
    args[k] = v;
  }
}
const out = obj => { console.log(JSON.stringify(obj, null, 2)); };
const fail = msg => { out({ ok: false, error: msg }); process.exit(1); };
if (!command) fail('Usage: maple.js <command> --case <id> [--flag value]');
if (!args.case) fail('Missing --case <id>. Every command needs the case ID.');

const runsDir = path.join(ROOT, 'runs');
const traceFile = path.join(runsDir, `${args.case}.trace.json`);

function loadTrace() {
  if (!fs.existsSync(traceFile)) fail(`No trace for ${args.case}. Run "start --case ${args.case}" first.`);
  return JSON.parse(fs.readFileSync(traceFile, 'utf8'));
}
function record(trace, span) {
  const now = Date.now();
  const s = {
    span_id: `${trace.trace_id}-s${String(trace.spans.length + 1).padStart(2, '0')}`,
    ...span,
    start_offset_ms: now - trace.started_ms,
    latency_ms: now - trace.last_ms
  };
  trace.last_ms = now;
  trace.spans.push(s);
  const tools = trace.spans.filter(x => x.type === 'tool');
  trace.totals = {
    spans: trace.spans.length,
    tool_calls: tools.length,
    tool_errors: tools.filter(x => x.status === 'error').length,
    latency_ms: now - trace.started_ms
  };
  fs.writeFileSync(traceFile, JSON.stringify(trace, null, 2));
}
function tool(name, input, fn) {
  const trace = loadTrace();
  if (trace.output !== null) fail(`Case ${args.case} already has a reply. Run "start" again to redo it.`);
  const r = fn();
  record(trace, { type: 'tool', name, input, output: r.ok ? r.data : null, status: r.ok ? 'ok' : 'error', ...(r.ok ? {} : { error: r.error }) });
  out(r.ok ? { ok: true, ...r.data } : { ok: false, error: r.error });
}

const orders = () => read('data/orders.json');
const findOrder = id => orders().find(o => o.order_id === id);
const need = k => { if (!args[k] || args[k] === true) fail(`Missing --${k}`); return args[k]; };

switch (command) {
  case 'start': {
    const f = path.join(ROOT, 'cases', `${args.case}.md`);
    if (!fs.existsSync(f)) fail(`Case file cases/${args.case}.md not found.`);
    const raw = fs.readFileSync(f, 'utf8');
    const meta = Object.fromEntries((raw.match(/^---\n([\s\S]*?)\n---/) || [, ''])[1].split('\n').filter(Boolean).map(l => l.split(/:\s*/)));
    const message = raw.replace(/^---[\s\S]*?---\n/, '').trim();
    const skill = fs.readFileSync(SKILL_FILE, 'utf8');
    fs.mkdirSync(runsDir, { recursive: true });
    const now = Date.now();
    const trace = {
      trace_id: args.case,
      started_at: new Date(now).toISOString(),
      agent: 'maple-support',
      skill_hash: crypto.createHash('sha256').update(skill).digest('hex').slice(0, 12),
      model: args.model && args.model !== true ? args.model : 'unspecified',
      input: { customer_id: meta.customer_id, message },
      output: null,
      spans: [],
      started_ms: now,
      last_ms: now
    };
    fs.writeFileSync(traceFile, JSON.stringify(trace, null, 2));
    out({ ok: true, case: args.case, customer_id: meta.customer_id, message, today: TODAY });
    break;
  }
  case 'lookup_order':
    tool('lookup_order', { order_id: need('order') }, () => {
      const o = findOrder(args.order);
      return o ? { ok: true, data: o } : { ok: false, error: `order ${args.order} not found` };
    });
    break;
  case 'get_customer':
    tool('get_customer', { customer_id: need('customer') }, () => {
      const c = read('data/customers.json').find(x => x.customer_id === args.customer);
      return c ? { ok: true, data: c } : { ok: false, error: `customer ${args.customer} not found` };
    });
    break;
  case 'check_return':
    tool('check_return', { order_id: need('order') }, () => {
      const o = findOrder(args.order);
      if (!o) return { ok: false, error: `order ${args.order} not found` };
      if (!o.delivered_at) return { ok: true, data: { eligible: false, reason: 'Order has not been delivered.' } };
      const days = Math.round((new Date(TODAY) - new Date(o.delivered_at)) / 86400000);
      return { ok: true, data: { eligible: days <= 30, days_since_delivery: days, reason: days <= 30 ? 'Within the 30-day return window.' : `Delivered ${days} days ago, outside the 30-day window.` } };
    });
    break;
  case 'search_policy':
    tool('search_policy', { query: need('query') }, () => {
      const dir = path.join(ROOT, 'data', 'policies');
      const words = String(args.query).toLowerCase().split(/\W+/).filter(w => w.length > 2);
      const docs = fs.readdirSync(dir).map(f => {
        const text = fs.readFileSync(path.join(dir, f), 'utf8');
        return { doc_id: f.replace('.md', ''), text, score: words.filter(w => text.toLowerCase().includes(w)).length };
      }).sort((a, b) => b.score - a.score);
      const d = docs[0];
      return { ok: true, data: { doc_id: d.doc_id, passages: d.text.split('\n').filter(l => l.startsWith('- ')).map(l => l.slice(2)) } };
    });
    break;
  case 'refund':
    tool('refund', { order_id: need('order'), amount: Number(need('amount')) }, () =>
      ({ ok: true, data: { refund_id: 'RF-' + args.order.slice(2), order_id: args.order, amount: Number(args.amount), status: 'initiated', method: 'original payment' } }));
    break;
  case 'return_label':
    tool('return_label', { order_id: need('order') }, () => ({ ok: true, data: { label_url: `https://returns.maple.example/label/${args.order}` } }));
    break;
  case 'create_ticket':
    tool('create_ticket', { order_id: need('order'), subject: need('subject') }, () =>
      ({ ok: true, data: { ticket_id: 'TK-' + args.order.slice(2), subject: args.subject, status: 'open' } }));
    break;
  case 'escalate':
    tool('escalate', { ticket_id: need('ticket'), reason: need('reason') }, () =>
      ({ ok: true, data: { ticket_id: args.ticket, queue: 'senior-support', sla: '1 hour' } }));
    break;
  case 'update_address':
    tool('update_address', { order_id: need('order'), address: need('address') }, () => {
      const faults = read('data/.sim/faults.json').update_address || {};
      if (faults[args.order]) return { ok: false, error: faults[args.order] };
      const o = findOrder(args.order);
      if (!o) return { ok: false, error: `order ${args.order} not found` };
      return { ok: true, data: { order_id: args.order, shipping_address: args.address, updated: true } };
    });
    break;
  case 'note': {
    const trace = loadTrace();
    record(trace, { type: 'llm', name: 'note', input: null, output: { thought: need('text') }, status: 'ok' });
    out({ ok: true });
    break;
  }
  case 'reply': {
    const trace = loadTrace();
    if (trace.output !== null) fail(`Case ${args.case} already has a reply.`);
    const text = need('text');
    record(trace, { type: 'llm', name: 'reply', input: null, output: { reply: text }, status: 'ok' });
    trace.output = text;
    fs.writeFileSync(traceFile, JSON.stringify(trace, null, 2));
    out({ ok: true, recorded: true });
    break;
  }
  default:
    fail(`Unknown command "${command}".`);
}
