# Maple skill lab

This repo has two sides. Keep them separate.

**System under test:** the `Maple Support` custom agent (`.github/agents/maple-support.agent.md`) and its `maple-support` skill (`.github/skills/maple-support/`). It handles the customer cases in `cases/` using `data/`. Its tool script records every run in `runs/<case>.trace.json`.

**Evaluation side:** `evals/`, `scripts/`, `tests/`, `review/` and the Trace Investigator, eval-writer and skill-fixer agents. They read traces, find failures, write evals and improve the skill.

- The system under test must never read or change the evaluation side.
- `runs/` holds production traces. Never edit them by hand; re-run a case to replace its trace.
- Node.js 20+, CommonJS, no third-party dependencies.
- Commands: `npm run list`, `npm run view -- C-01`, `npm run detect`, `npm run evals`, `npm test`.
