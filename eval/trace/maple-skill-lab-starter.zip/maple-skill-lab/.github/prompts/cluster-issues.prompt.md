---
description: Axial coding - group open-coding notes into an error taxonomy with counts.
agent: agent
model: Claude Sonnet 5 (copilot)
---
Read `review/open-coding.md` and group the notes into clusters.

- Name each cluster after the behavior the customer experienced.
- Tag each one: context, decision, execution, or trajectory/cost.
- Count cases per cluster and list the IDs.
- Point to the SKILL.md instruction that most likely causes it.
- Recommend which clusters deserve an eval, weighing frequency and user impact, with one sentence of reasoning each.

Write the result to `review/taxonomy.md` using its table. Don't write code.
