---
description: Run support cases through the Maple Support agent so each one leaves a trace in runs/.
agent: Maple Support
model: Claude Sonnet 5 (copilot)
---
Handle these support cases: ${input:cases:all}

If the value is "all", handle every file in `cases/` in order. Otherwise handle only the listed case IDs.

For each case, follow the `maple-support` skill from `start` to `reply`. Pass `--model "Claude Sonnet 5"` to `start`.
Handle each case independently and don't carry assumptions from one case to the next.

When you've finished, list each case ID with a one-line summary of what you did.
