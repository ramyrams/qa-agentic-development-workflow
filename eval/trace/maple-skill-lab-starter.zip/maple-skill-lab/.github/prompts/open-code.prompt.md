---
description: Open-code the Maple Support traces - one free-form note per problem, with case IDs.
agent: agent
model: Claude Sonnet 5 (copilot)
---
Help me open-code the traces in `runs/`.

1. Run `npm run list`, then `npm run view -- <id>` for every case. Read every span, not just the reply.
2. For each problem, write ONE short free-form note: what happened and which span shows it. Don't assign categories yet.
3. If a case looks fine, write "no issue" and why you believe the reply is grounded.
4. Judge against `data/policies/`, not against the skill.
5. Append the notes to `review/open-coding.md` as a table: case | note | evidence span.

Be skeptical of fluent replies. I'll review and edit every note.
