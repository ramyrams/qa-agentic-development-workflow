---
applyTo: "evals/**"
---
- Every eval exports `id`, `cluster`, `type`, `rubric {pass, fail, na}`, `applies(trace)` and `check(trace) -> {pass, reason}`. Follow `evals/trace-complete.eval.js` and use `evals/lib/trace-utils.js`.
- Encode business rules from `data/policies/`. Never read `SKILL.md` from an eval: if the skill changes, the test must not change with it.
- Trace shape: `trace_id`, `skill_hash`, `input {customer_id, message}`, `output` (the reply), `spans[]` with `type` ("tool" or "llm"), `name`, `input`, `output`, `status`, optional `error`; and `totals`.
