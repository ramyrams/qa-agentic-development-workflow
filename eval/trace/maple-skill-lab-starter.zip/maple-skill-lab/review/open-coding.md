# Open coding notes

| Case | Note | Evidence span |
|---|---|---|
