# Error taxonomy

| Cluster | Category | Description | Cases | Count | Likely SKILL.md cause | Eval? (why) |
|---|---|---|---|---|---|---|
