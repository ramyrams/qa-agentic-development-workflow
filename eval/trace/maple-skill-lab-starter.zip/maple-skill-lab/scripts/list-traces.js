// One line per case: status, tool calls, input and reply.  Usage: npm run list
const { requireTraces } = require('./load-traces');
const { skillHash } = require('./skill-hash');
const current = skillHash();
const cut = (s, n) => (s.length > n ? s.slice(0, n - 1) + '…' : s.padEnd(n));
for (const t of requireTraces()) {
  const stale = t.skill_hash !== current ? ' (stale skill)' : '';
  console.log(`${t.trace_id}  ${String(t.totals ? t.totals.tool_calls : 0).padStart(2)} tools  ${cut(t.input.message, 50)}  →  ${cut(t.output || '(no reply)', 70)}${stale}`);
}
console.log(`\nCurrent skill hash: ${current}`);
