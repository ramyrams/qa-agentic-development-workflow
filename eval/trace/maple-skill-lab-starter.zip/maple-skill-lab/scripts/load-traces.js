// Loads traces from runs/ (or --dir=<folder>). Each file is one case: runs/<case>.trace.json
const fs = require('fs');
const path = require('path');

function traceDir() {
  const flag = process.argv.find(a => a.startsWith('--dir='));
  return flag ? path.resolve(flag.slice(6)) : path.join(__dirname, '..', 'runs');
}

function loadTraces(dir = traceDir()) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter(f => f.endsWith('.trace.json'))
    .sort()
    .map(f => JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')));
}

function requireTraces() {
  const t = loadTraces();
  if (!t.length) {
    console.error(`No traces in ${path.relative(process.cwd(), traceDir()) || '.'}. Run the cases with the Maple Support agent first (see /run-cases).`);
    process.exit(1);
  }
  return t;
}

module.exports = { loadTraces, requireTraces, traceDir };
