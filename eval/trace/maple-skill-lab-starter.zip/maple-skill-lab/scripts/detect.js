// Runs detection rules over the traces.  Usage: npm run detect
const { requireTraces } = require('./load-traces');
const rules = require('../evals/detections');
const traces = requireTraces();
let n = 0;
for (const t of traces) {
  const hits = rules.filter(r => r.test(t)).map(r => r.id);
  if (hits.length) { n++; console.log(`${t.trace_id}  [${hits.join(', ')}]  ${t.input.message}`); }
}
console.log(`\n${n} of ${traces.length} traces flagged by ${rules.length} rule(s): ${rules.map(r => r.id).join(', ')}`);
