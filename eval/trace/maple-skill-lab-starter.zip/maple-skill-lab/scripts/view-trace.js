// Prints one case trace as a span timeline.  Usage: npm run view -- C-09 [--json] [--dir=folder]
const { requireTraces } = require('./load-traces');
const id = process.argv.slice(2).find(a => !a.startsWith('--'));
if (!id) { console.error('Usage: npm run view -- <case-id> [--json]'); process.exit(1); }
const t = requireTraces().find(x => x.trace_id === id);
if (!t) { console.error(`No trace for ${id}.`); process.exit(1); }
if (process.argv.includes('--json')) { console.log(JSON.stringify(t, null, 2)); process.exit(0); }
const tty = process.stdout.isTTY;
const c = (code, s) => (tty ? `\x1b[${code}m${s}\x1b[0m` : s);
const short = v => { const s = JSON.stringify(v); return s && s.length > 170 ? s.slice(0, 167) + '...' : s; };
console.log(c(1, `Trace ${t.trace_id}`) + c(2, `  skill ${t.skill_hash}  model ${t.model}  ${t.started_at}`));
console.log(`Customer ${t.input.customer_id}: ${t.input.message}\n`);
for (const s of t.spans) {
  const tag = s.type === 'tool' ? c(33, 'TOOL') : c(36, 'LLM ');
  console.log(`${tag} ${c(1, s.name)}${s.status === 'error' ? c(31, ' ERROR') : ''}  ${c(2, `+${s.start_offset_ms}ms`)}`);
  if (s.type === 'tool') {
    console.log(c(2, '     in  ') + short(s.input));
    console.log(c(2, '     out ') + (s.error ? c(31, s.error) : short(s.output)));
  } else if (s.name === 'note') console.log(c(2, '     ') + s.output.thought);
}
console.log(`\n${c(1, 'Reply')}: ${t.output || '(none)'}`);
if (t.totals) console.log(c(2, `\n${t.totals.tool_calls} tool calls, ${t.totals.tool_errors} tool errors, ${t.totals.latency_ms}ms`));
