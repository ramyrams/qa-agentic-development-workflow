// Scores every trace with every eval.  Usage: npm run evals [-- --verbose] [-- --dir=folder]
const { requireTraces } = require('./load-traces');
const { loadEvals } = require('../evals/load-evals');
const verbose = process.argv.includes('--verbose');
const traces = requireTraces();
const evals = loadEvals();
console.log(`Scoring ${traces.length} traces with ${evals.length} eval(s)\n`);
let anyFail = false;
for (const e of evals) {
  const app = traces.filter(t => e.applies(t));
  const fails = app.map(t => ({ t, r: e.check(t) })).filter(x => !x.r.pass);
  if (fails.length) anyFail = true;
  console.log(`${e.id.padEnd(24)} ${e.type.padEnd(14)} applies ${String(app.length).padStart(2)}  pass ${String(app.length - fails.length).padStart(2)}  fail ${String(fails.length).padStart(2)}`);
  if (fails.length) console.log(`${''.padEnd(26)}failing: ${fails.map(x => x.t.trace_id).join(', ')}`);
  if (verbose) fails.forEach(x => console.log(`${''.padEnd(28)}${x.t.trace_id}: ${x.r.reason}`));
}
process.exitCode = anyFail ? 1 : 0;
