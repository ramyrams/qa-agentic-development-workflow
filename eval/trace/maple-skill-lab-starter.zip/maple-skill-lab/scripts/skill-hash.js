// Hash of the current SKILL.md. Traces record the hash they ran with, so stale traces are detectable.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const SKILL = path.join(__dirname, '..', '.github', 'skills', 'maple-support', 'SKILL.md');
const skillHash = () => crypto.createHash('sha256').update(fs.readFileSync(SKILL, 'utf8')).digest('hex').slice(0, 12);
module.exports = { skillHash };
if (require.main === module) console.log(skillHash());
