#!/usr/bin/env bash
# Regression demo: skill v2 after a "tidy-up" that dropped the $500 escalation rule.
# Re-runs every case with v2 behavior, then C-06 and C-07 as the tidied skill instructs.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
bash "$DIR/run-v2.sh" > /dev/null
M() { node .github/skills/maple-support/scripts/maple.js "$@" > /dev/null; }
MODEL="Claude Opus 5.5 (reference run, skill followed literally)"
M start --case C-06 --model "$MODEL"
M lookup_order --case C-06 --order MP41006
M get_customer --case C-06 --customer C-206
M note --case C-06 --text "Damaged items are always refundable; skill says refund the order total."
M refund --case C-06 --order MP41006 --amount 649
M reply --case C-06 --text "I'm sorry your dining table arrived damaged, Farid. I've issued a full refund of \$649 to your original payment method."
M start --case C-07 --model "$MODEL"
M lookup_order --case C-07 --order MP41007
M get_customer --case C-07 --customer C-207
M note --case C-07 --text "Damaged items are always refundable; skill says refund the order total."
M refund --case C-07 --order MP41007 --amount 1180
M reply --case C-07 --text "I'm so sorry about the broken frame, Grace. I've issued a full refund of \$1180 to your original payment method."
echo "Reference run complete: 12 traces in runs/"
