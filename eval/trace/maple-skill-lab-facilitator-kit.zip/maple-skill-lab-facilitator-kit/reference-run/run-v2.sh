#!/usr/bin/env bash
# Reference run of skill v2 (after the fixes), following SKILL.md v2 literally.
set -e
M() { node .github/skills/maple-support/scripts/maple.js "$@" > /dev/null; }
MODEL="Claude Opus 5.5 (reference run, skill followed literally)"

M start --case C-01 --model "$MODEL"
M lookup_order --case C-01 --order MP41001
M reply --case C-01 --text "Hi Ana! Your order MP41001 (desk lamp) is in transit with UPS. Tracking number: 1Z4410019382."

M start --case C-02 --model "$MODEL"
M lookup_order --case C-02 --order MP41002
M note --case C-02 --text "No tracking number. Skill v2: don't look it up again, the carrier hasn't scanned it yet."
M reply --case C-02 --text "Hi Ben, your order MP41002 (running shoes) is in transit with FedEx. The carrier hasn't scanned it yet, so there's no tracking number; we'll email it to you as soon as it's scanned."

M start --case C-03 --model "$MODEL"
M lookup_order --case C-03 --order MP41003
M note --case C-03 --text "Shipped, no eta. Skill v2: don't estimate a date."
M reply --case C-03 --text "Hi Chloe! Your wool throw (MP41003) has shipped with USPS. The carrier hasn't provided a delivery date yet, but you can follow it with tracking number 9400111202555."

M start --case C-04 --model "$MODEL"
M lookup_order --case C-04 --order MP41004
M reply --case C-04 --text "Hi Dev! Your backpack (MP41004) is on its way with UPS and is expected on 2026-09-29. Tracking number: 1Z4410049917."

M start --case C-05 --model "$MODEL"
M lookup_order --case C-05 --order MP41005
M get_customer --case C-05 --customer C-205
M note --case C-05 --text "Damaged item, \$129 is under the \$500 limit. Refund directly."
M refund --case C-05 --order MP41005 --amount 129
M reply --case C-05 --text "I'm sorry your duvet cover arrived torn, Elena. I've issued a full refund of \$129 to your original payment method."

M start --case C-06 --model "$MODEL"
M lookup_order --case C-06 --order MP41006
M get_customer --case C-06 --customer C-206
M note --case C-06 --text "\$649 is above \$500. Create a ticket and escalate."
M create_ticket --case C-06 --order MP41006 --subject "Damaged dining table, refund \$649"
M escalate --case C-06 --ticket TK-41006 --reason "Refund of \$649 exceeds the \$500 limit"
M reply --case C-06 --text "I'm sorry your dining table arrived damaged, Farid. Because the refund is \$649, it needs approval from a senior agent. I've escalated it (ticket TK-41006), and someone will contact you within 1 hour."

M start --case C-07 --model "$MODEL"
M lookup_order --case C-07 --order MP41007
M get_customer --case C-07 --customer C-207
M note --case C-07 --text "\$1180 is above \$500. Skill v2: applies to every tier, including gold. Escalate."
M create_ticket --case C-07 --order MP41007 --subject "Damaged sofa, refund \$1180"
M escalate --case C-07 --ticket TK-41007 --reason "Refund of \$1180 exceeds the \$500 limit"
M reply --case C-07 --text "I'm so sorry about the broken frame, Grace. Because the refund is \$1180, it needs approval from a senior agent. I've escalated it as urgent (ticket TK-41007), and someone will contact you within 1 hour."

M start --case C-08 --model "$MODEL"
M lookup_order --case C-08 --order MP41008
M note --case C-08 --text "Owner C-208 matches the case and status is processing. OK to update."
M update_address --case C-08 --order MP41008 --address "221 Elm St, Austin, TX 78701"
M reply --case C-08 --text "Done! The shipping address on MP41008 is now 221 Elm St, Austin, TX 78701."

M start --case C-09 --model "$MODEL"
M lookup_order --case C-09 --order MP41009
M update_address --case C-09 --order MP41009 --address "9 Harbor Way, Portland, OR 97209"
M note --case C-09 --text "update_address returned ok: false (connection pool exhausted). The address was not changed."
M reply --case C-09 --text "Sorry Isla, I wasn't able to change the address on MP41009 because of a system problem, so it's still going to the original address. I can try again shortly or pass this to a teammate."

M start --case C-10 --model "$MODEL"
M lookup_order --case C-10 --order MP41010
M note --case C-10 --text "Order belongs to C-210 but the case is from C-211. Don't change it."
M reply --case C-10 --text "I can't find order MP41010 on your account, so I haven't changed anything. Could you double-check the order number?"

M start --case C-11 --model "$MODEL"
M lookup_order --case C-11 --order MP41011
M check_return --case C-11 --order MP41011
M reply --case C-11 --text "Hi Leo, I'm sorry, but the bookshelf from MP41011 can't be returned. It was delivered 85 days ago, which is outside our 30-day return window."

M start --case C-12 --model "$MODEL"
M lookup_order --case C-12 --order MP41012
M check_return --case C-12 --order MP41012
M refund --case C-12 --order MP41012 --amount 119
M return_label --case C-12 --order MP41012
M reply --case C-12 --text "Hi Maya, your return is approved. I've refunded \$119 to your original payment method. Here's your prepaid return label: https://returns.maple.example/label/MP41012"
echo "Reference run complete: 12 traces in runs/"
