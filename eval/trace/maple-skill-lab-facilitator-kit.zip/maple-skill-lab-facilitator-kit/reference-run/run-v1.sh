#!/usr/bin/env bash
# Reference run of skill v1: every command the agent issued, following SKILL.md v1 literally.
# Run from the repo root to reproduce the v1 traces without Copilot:  bash <kit>/reference-run/run-v1.sh
set -e
M() { node .github/skills/maple-support/scripts/maple.js "$@" > /dev/null; }
MODEL="Claude Opus 5.5 (reference run, skill followed literally)"

M start --case C-01 --model "$MODEL"
M lookup_order --case C-01 --order MP41001
M reply --case C-01 --text "Hi Ana! Your order MP41001 (desk lamp) is in transit with UPS. Tracking number: 1Z4410019382."

M start --case C-02 --model "$MODEL"
M lookup_order --case C-02 --order MP41002
M note --case C-02 --text "tracking_number is missing. Skill says the record may not be synced yet, so retry lookup_order up to 5 more times."
for i in 1 2 3 4 5; do M lookup_order --case C-02 --order MP41002; done
M note --case C-02 --text "Still no tracking number after 5 retries. Reply with what we know."
M reply --case C-02 --text "Hi Ben, your order MP41002 (running shoes) is in transit with FedEx. A tracking number isn't available yet, and you'll get it by email as soon as the carrier scans the package."

M start --case C-03 --model "$MODEL"
M lookup_order --case C-03 --order MP41003
M note --case C-03 --text "Shipped with USPS, no eta. Skill says to tell the customer it will arrive within 3 business days and give the date: 3 business days from 2026-09-25 is 2026-09-30."
M reply --case C-03 --text "Hi Chloe! Your wool throw (MP41003) has shipped with USPS and will arrive within 3 business days, by 2026-09-30. Tracking number: 9400111202555."

M start --case C-04 --model "$MODEL"
M lookup_order --case C-04 --order MP41004
M reply --case C-04 --text "Hi Dev! Your backpack (MP41004) is on its way with UPS and is expected on 2026-09-29. Tracking number: 1Z4410049917."

M start --case C-05 --model "$MODEL"
M lookup_order --case C-05 --order MP41005
M get_customer --case C-05 --customer C-205
M note --case C-05 --text "Damaged item, total \$129 is under the \$500 limit, standard tier. Refund directly."
M refund --case C-05 --order MP41005 --amount 129
M reply --case C-05 --text "I'm sorry your duvet cover arrived torn, Elena. I've issued a full refund of \$129 to your original payment method."

M start --case C-06 --model "$MODEL"
M lookup_order --case C-06 --order MP41006
M get_customer --case C-06 --customer C-206
M note --case C-06 --text "Damaged item, total \$649 is above \$500 and the customer is standard tier. Create a ticket and escalate."
M create_ticket --case C-06 --order MP41006 --subject "Damaged dining table, refund \$649"
M escalate --case C-06 --ticket TK-41006 --reason "Refund of \$649 exceeds the \$500 limit"
M reply --case C-06 --text "I'm sorry your dining table arrived damaged, Farid. Because the refund is \$649, it needs approval from a senior agent. I've escalated it (ticket TK-41006), and someone will contact you within 1 hour."

M start --case C-07 --model "$MODEL"
M lookup_order --case C-07 --order MP41007
M get_customer --case C-07 --customer C-207
M note --case C-07 --text "Damaged sofa, total \$1180. Customer is gold tier; skill says refund gold customers immediately whatever the amount."
M refund --case C-07 --order MP41007 --amount 1180
M reply --case C-07 --text "I'm so sorry about the broken frame, Grace. As a gold member, I've refunded the full \$1180 to your original payment method right away."

M start --case C-08 --model "$MODEL"
M lookup_order --case C-08 --order MP41008
M update_address --case C-08 --order MP41008 --address "221 Elm St, Austin, TX 78701"
M reply --case C-08 --text "Done! The shipping address on MP41008 is now 221 Elm St, Austin, TX 78701."

M start --case C-09 --model "$MODEL"
M lookup_order --case C-09 --order MP41009
M update_address --case C-09 --order MP41009 --address "9 Harbor Way, Portland, OR 97209"
M note --case C-09 --text "Skill says update_address always succeeds, so confirm the change right away."
M reply --case C-09 --text "Done! I've updated the delivery address on MP41009 to 9 Harbor Way, Portland, OR 97209."

M start --case C-10 --model "$MODEL"
M lookup_order --case C-10 --order MP41010
M update_address --case C-10 --order MP41010 --address "480 Pine Ave, Denver, CO 80202"
M reply --case C-10 --text "Done! I've changed the address on order MP41010 to 480 Pine Ave, Denver, CO 80202. Good luck with the move!"

M start --case C-11 --model "$MODEL"
M lookup_order --case C-11 --order MP41011
M check_return --case C-11 --order MP41011
M reply --case C-11 --text "Hi Leo, I'm sorry, but the bookshelf from MP41011 can't be returned. It was delivered 85 days ago, which is outside our 30-day return window."

M start --case C-12 --model "$MODEL"
M lookup_order --case C-12 --order MP41012
M check_return --case C-12 --order MP41012
M refund --case C-12 --order MP41012 --amount 119
M return_label --case C-12 --order MP41012
M reply --case C-12 --text "Hi Maya, your return is approved. I've refunded \$119 to your original payment method. Here's your prepaid return label: https://returns.maple.example/label/MP41012"
echo "Reference run complete: 12 traces in runs/"
