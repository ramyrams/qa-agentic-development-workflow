# 15-minute demo script

Preparation: open the learner repo, select Agent mode with Claude Sonnet 5, and run `/run-cases` beforehand. If it's slow or unavailable, use the reference traces with `--dir=samples/reference-v1-runs`. Keep the kit's `solution/` folder handy.

| Min | Do | Say |
|---|---|---|
| 0-2 | Open `SKILL.md` and `data/policies/returns.md` side by side | "The skill is the system under test. Policy defines correct. Can you spot the problem by reading? Most people can't find all of them." |
| 2-4 | `npm run view -- C-06`, then `npm run view -- C-09` | "Both replies read well. C-09's tool errored and the reply says Done." |
| 4-6 | `npm run detect` | "Rules catch the crash. They can't see the gold-tier refund or the invented date." |
| 6-8 | **Trace Investigator**: "Investigate runs/ and list clusters with the SKILL.md instruction behind each." | Open one case to confirm it. "First pass, not a verdict." |
| 8-10 | Copy `solution/evals/*.js` into `evals/`; `npm run evals` | "Five clusters, five deterministic evals, each failing on exactly one case." |
| 10-13 | **skill-fixer** fixes SKILL.md; `npm test` shows everything stale; use its handoff to re-run the cases; `npm test` goes green | "Changing the skill invalidates every trace. The suite forces a re-run." |
| 13-15 | Delete the $500 sentence from the damaged-items section; re-run C-06 and C-07; `npm test` | "A 'tidy-up' reintroduced a policy violation, and the suite caught it." |
