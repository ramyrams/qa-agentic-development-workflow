# Answer key

## Seeded instruction flaws in SKILL.md v1
| # | SKILL.md v1 instruction | Policy it breaks | Case | Cluster / category | Eval that catches it |
|---|---|---|---|---|---|
| 1 | Retry `lookup_order` up to 5 more times when tracking is missing | (wasteful path) | C-02 | Lookup loop / trajectory | tool-call-budget |
| 2 | With no ETA, "tell them it will arrive within 3 business days and give the date" | shipping.md: only promise carrier dates; support.md: only state facts | C-03 | Invented delivery date / context | grounded-dates |
| 3 | "Gold-tier customers... refund them immediately whatever the amount" | returns.md: >$500 needs approval, every tier | C-07 | Refund above limit / decision | refund-escalation |
| 4 | "`update_address` always succeeds, so confirm the change right away" | support.md: never claim a failed action | C-09 | Success claimed after failure / execution | silent-tool-failure |
| 5 | (missing) no ownership check before changing an order | shipping.md: only the customer who placed it | C-10 | Changed another customer's order / decision | account-ownership |

## Reference results
- **v1:** 5 of 12 cases fail, one per cluster (see `reference-run/v1-evals.txt`). Golden suite with the 7 starter cases: 7/7 pass.
- **Detections:** the starter `tool-error` rule flags only C-09. Adding `too-many-tool-calls` adds C-02. Detections never catch C-03, C-07 or C-10.
- **After editing SKILL.md to v2**, before re-running: `npm test` reports all golden cases stale.
- **v2 re-run:** every eval passes on all 12 cases, and `npm test` passes 12/12 with the 5 failing cases added to golden.
- **v2 "tidied"** (the $500 rule removed): `npm test` fails C-06 and C-07 on refund-escalation.

## What differs with Sonnet in Copilot
Expect some flaws to be "rescued" by the model. Flaws 1 and 5 are the most likely to be skipped sometimes: the model may stop retrying early or notice the owner mismatch. Flaws 2, 3 and 4 are explicit instructions and usually reproduce. If a flaw doesn't reproduce, discuss it: the skill is still wrong, and the eval guards against the day a model does follow it.
