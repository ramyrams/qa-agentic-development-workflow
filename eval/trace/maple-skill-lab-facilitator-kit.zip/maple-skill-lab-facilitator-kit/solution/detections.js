module.exports = [
  { id: 'tool-error', label: 'A tool call returned an error', test: t => t.totals.tool_errors > 0 },
  { id: 'too-many-tool-calls', label: 'More than 5 tool calls', test: t => t.totals.tool_calls > 5 },
  { id: 'no-reply', label: 'Case never replied to', test: t => t.output === null }
];
