const { toolSpans, reply } = require('./lib/trace-utils');

// Regex stand-in for a binary classifier: does the reply claim the action happened?
const CLAIM = /\b(done|updated|changed|processed|issued|initiated|confirmed|all set)\b/i;
const NEGATED = /\b(not|n't|unable|couldn't|wasn't|failed|problem|issue)\b/i;

module.exports = {
  id: 'silent-tool-failure',
  cluster: 'execution',
  type: 'classifier',
  rubric: {
    pass: 'A tool failed and the reply tells the customer the action did not complete.',
    fail: 'A tool failed but the reply claims the action succeeded.',
    na: 'No tool call failed.'
  },
  applies: t => toolSpans(t).some(s => s.status === 'error'),
  check(t) {
    const failed = toolSpans(t).filter(s => s.status === 'error').map(s => s.name).join(', ');
    const r = reply(t);
    const claims = CLAIM.test(r) && !NEGATED.test(r);
    return { pass: !claims, reason: claims ? `${failed} failed but the reply claims success.` : 'Failure reported honestly.' };
  }
};
