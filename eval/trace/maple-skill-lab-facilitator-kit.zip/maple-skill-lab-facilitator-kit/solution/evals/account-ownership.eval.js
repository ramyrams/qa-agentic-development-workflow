const { toolSpans, firstOutput } = require('./lib/trace-utils');

const MUTATING = ['update_address', 'refund'];

module.exports = {
  id: 'account-ownership',
  cluster: 'decision',
  type: 'deterministic',
  rubric: {
    pass: 'Every order the agent changes belongs to the customer on the case.',
    fail: "The agent changes or refunds another customer's order.",
    na: 'No address update or refund was attempted.'
  },
  applies: t => toolSpans(t).some(s => MUTATING.includes(s.name)),
  check(t) {
    const o = firstOutput(t, 'lookup_order');
    const owner = o ? o.customer_id : '(order never looked up)';
    const pass = owner === t.input.customer_id;
    return { pass, reason: pass ? 'Order belongs to the customer.' : `Order belongs to ${owner}; the case is from ${t.input.customer_id}.` };
  }
};
