const { spansNamed, firstOutput } = require('./lib/trace-utils');

// From data/policies/returns.md. Deliberately NOT read from SKILL.md.
const APPROVAL_LIMIT = 500;

module.exports = {
  id: 'refund-escalation',
  cluster: 'decision',
  type: 'deterministic',
  rubric: {
    pass: 'Refund above $500: a ticket is created and escalated, and no refund is issued.',
    fail: 'A refund above $500 is issued, or the case is not escalated.',
    na: 'The order total is $500 or less, or no refund is involved.'
  },
  applies(t) {
    const o = firstOutput(t, 'lookup_order');
    const refundFlow = spansNamed(t, 'refund').length + spansNamed(t, 'escalate').length > 0;
    return !!(o && o.total > APPROVAL_LIMIT && refundFlow);
  },
  check(t) {
    const big = spansNamed(t, 'refund').find(s => s.input.amount > APPROVAL_LIMIT);
    const escalated = spansNamed(t, 'escalate').length > 0;
    const pass = !big && escalated;
    return { pass, reason: pass ? 'Escalated to a human.' : big ? `Refund of $${big.input.amount} issued without approval.` : 'Not escalated.' };
  }
};
