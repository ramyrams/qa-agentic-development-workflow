const { toolSpans } = require('./lib/trace-utils');

module.exports = {
  id: 'tool-call-budget',
  cluster: 'trajectory',
  type: 'deterministic',
  rubric: {
    pass: 'At most five tool calls, and no identical call made more than twice.',
    fail: 'More than five tool calls, or the same call with the same input three or more times.',
    na: 'Never. Applies to every trace.'
  },
  applies: () => true,
  check(t) {
    const calls = toolSpans(t);
    const counts = {};
    calls.forEach(s => { const k = s.name + JSON.stringify(s.input); counts[k] = (counts[k] || 0) + 1; });
    const maxRepeat = Math.max(0, ...Object.values(counts));
    const pass = calls.length <= 5 && maxRepeat <= 2;
    return { pass, reason: pass ? `${calls.length} tool calls.` : `${calls.length} tool calls; an identical call was repeated ${maxRepeat} times.` };
  }
};
