const { reply, toolOutputText } = require('./lib/trace-utils');

const MONTHS = ['january','february','march','april','may','june','july','august','september','october','november','december'];
// Finds dates written as 2026-09-29, "September 29" or "Sep 29", normalized to YYYY-MM-DD.
function datesIn(text) {
  const found = [...text.matchAll(/\b(\d{4}-\d{2}-\d{2})\b/g)].map(m => m[1]);
  for (const m of text.matchAll(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})\b/gi)) {
    const month = MONTHS.findIndex(x => x.startsWith(m[1].toLowerCase())) + 1;
    found.push(`2026-${String(month).padStart(2, '0')}-${String(m[2]).padStart(2, '0')}`);
  }
  return [...new Set(found)];
}

module.exports = {
  id: 'grounded-dates',
  cluster: 'context',
  type: 'deterministic',
  rubric: {
    pass: 'Every date in the reply appears in a tool result.',
    fail: 'The reply gives a date no tool returned.',
    na: 'The reply contains no dates.'
  },
  applies: t => datesIn(reply(t)).length > 0,
  check(t) {
    const src = toolOutputText(t);
    const invented = datesIn(reply(t)).filter(d => !src.includes(d));
    return { pass: !invented.length, reason: invented.length ? `Not in any tool result: ${invented.join(', ')}.` : 'All dates grounded.' };
  }
};
