# Facilitator kit: Maple skill lab (keep away from learners until after the lab)

## What's here
- `answer-key.md` seeded flaws, the cases they break, and the expected eval results.
- `solution/evals/*.eval.js` and `solution/detections.js` reference evals and detection rules.
- `skill-versions/` SKILL.v1.md (as shipped), SKILL.v2.md (fixed), SKILL.v2-tidied.md (regression demo) and `v1-to-v2.diff`.
- `reference-run/` the validation run: shell scripts that replay every agent command, the resulting traces (`v1-runs/`, `v2-runs/`) and eval reports.
- `demo-script.md` 15-minute presenter version.

## About the reference run
The reference run was produced by Claude (Opus 5.5, in claude.ai) executing each version of SKILL.md literally, issuing the same tool-script commands the Copilot agent issues. It shows that the method works end to end and gives you a fallback dataset. Claude Sonnet 5 in Copilot will not behave identically: on some cases it may ignore a flawed instruction and do the right thing, and on others it may fail in new ways. That variation is the lesson. Run the cases more than once and compare.

To replay a reference run in the learner repo (Git Bash, macOS or Linux), from the repo root:
```
cp <kit>/skill-versions/SKILL.v1.md .github/skills/maple-support/SKILL.md
bash <kit>/reference-run/run-v1.sh
```
