# Kata 3 (Author): Full-Structure Skill

**Level:** Author gate (part 2 of 3)
**Time box:** 3-5 hours (can span multiple sessions)
**Materials:** a different real workflow than Kata 2 — pick something that
genuinely needs at least two of `references/`, `assets/`, `scripts/` (if it
only needs SKILL.md, it's not the right candidate for this kata).

## Task
Design and build a complete skill using the full folder pattern, modeled on
`add-rest-endpoint` or `pr-review`:
1. SKILL.md with clear Quick Start and Instructions sections
2. At least one `references/` file with content that would bloat SKILL.md
   if inlined
3. At least one `assets/` template OR `scripts/` executable — bonus for
   both
4. If you include a script, it must actually run successfully against a
   real file in your repo — not just look plausible

## Definition of Done
- Passes `audit-skill.js` mechanically (no blocking findings)
- Self-graded against `references/audit-criteria.md` in
  `audit-skill-quality` — attach your own filled-in
  `assets/audit-scorecard.md` as part of submission
- A teammate (peer, not the same person) can read only the description and
  correctly guess when to invoke it, without reading the rest of SKILL.md
- If a script is included, attach the actual terminal output of running it
  against a real file — not a description of what it would do

## Grading
Graded by an Architect-level reviewer using the full `audit-skill-quality`
process (script + qualitative criteria). This is the first kata where
someone else's judgment, not just a script, determines pass/fail.
