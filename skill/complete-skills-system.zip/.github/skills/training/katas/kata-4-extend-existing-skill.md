# Kata 4 (Author): Extend Without Breaking

**Level:** Author gate (part 3 of 3)
**Time box:** 1-2 hours
**Materials:** any existing catalog skill — your own from Kata 2/3, or a
shared one (with the owner's sign-off per `MAINTENANCE.md`).

## Task
Add real capability to an existing skill without changing what it already
does correctly:
1. Pick a gap — a scenario the skill's description doesn't cover, or a
   reference doc it's missing, or a manual step that could become a script.
2. Extend it. This should be a MINOR version bump per `MAINTENANCE.md`
   (capability added, no existing behavior changed).
3. Update `CATALOG.md`: bump the version, update `Last Audited` after
   re-running the audit.

## Definition of Done
- The skill's existing test prompts (from when it was first authored) still
  trigger and behave the same way — you must re-run them, not assume.
- `audit-skill.js` still passes clean after your change.
- `CATALOG.md` row updated correctly (version bump matches the
  MAJOR/MINOR/PATCH rule — a MINOR bump here, not MAJOR, is itself part of
  what's being graded).
- If you extended someone else's skill, their sign-off is attached.

## Why This Kata Exists
Most real-world skill work after initial launch is extension, not creation
from scratch. This is also the first kata that touches `MAINTENANCE.md`
directly — versioning discipline is graded, not just code quality.
