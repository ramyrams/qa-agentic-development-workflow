# Kata 6 (Architect): Catalog Decision

**Level:** Architect gate (part 2 of 2)
**Time box:** 30 minutes, discussion-based (pairs well with a team review
session rather than solo grading)

## Task
A teammate proposes a new skill: **"sql-query-helper"** — "helps write and
optimize SQL queries across the app."

Using `CATALOG.md` as it exists at the time (including whatever real skills
your team has shipped by this point), decide and justify:
1. Does this duplicate or overlap an existing skill enough that it should
   be a `MINOR` extension of an existing one instead of a new skill?
2. If it should be a new skill, is the proposed scope itself too broad
   (kitchen-sink), per the same standard as Kata 5?
3. Does it need a Governance Gate flag, and why or why not?
4. Draft the `CATALOG.md` row you'd approve it with — owner field intentionally
   left as a discussion point (who *should* own this, and why does that
   matter for whether it gets maintained?).

## Definition of Done
A written decision (few paragraphs, not a scorecard) covering all four
points, defensible to another Architect-level reviewer who might disagree.
This kata is graded on reasoning quality, not a single correct answer —
pair it with a live discussion where a second Architect pushes back on the
decision.

## Why This Kata Has No Fixed Answer Key
Unlike Kata 5, this is a judgment call that depends on what's actually in
your catalog at the time — the skill worth testing here is whether the
candidate reasons from `CATALOG.md` and `MAINTENANCE.md` correctly, not
whether they reach one specific verdict.
