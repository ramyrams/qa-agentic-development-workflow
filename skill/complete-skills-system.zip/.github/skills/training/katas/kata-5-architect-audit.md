# Kata 5 (Architect): Audit a Flawed Skill

**Level:** Architect gate (part 1 of 2)
**Time box:** 45 minutes
**Materials:** `kata-5-sample-to-audit/` in this folder — a real skill
folder with real, planted issues.

## Task
1. Run `audit-skill.js` against `kata-5-sample-to-audit/` and record its
   output.
2. Apply `audit-skill-quality/references/audit-criteria.md` for everything
   the script can't catch.
3. Fill in a complete `audit-scorecard.md` for this skill, including a
   verdict and required fixes.

## Definition of Done
Scorecard submitted with all mechanical AND qualitative findings below
identified, correctly severity-tagged, with a "Needs fixes" or "Needs
Governance Gate" verdict (not "Ready to ship").

---
## Answer Key (grader use — don't share with candidates before grading)

### What the script catches (verified — this is real tool output, not
hypothetical):
- 🔴 Frontmatter description too short/generic to convey trigger phrases
- 🔴 `references/schema-tips.md` referenced in SKILL.md but doesn't exist
- 🔴 `scripts/run-migration.js` is interactive (uses `readline`) — can't
  run unattended
- 🟡 Script doesn't read `process.argv`

### What only a qualitative reviewer should catch (this is the actual
grading bar for Architect level):
1. **Kitchen-sink scope** — the body description tries to cover queries,
   migrations, caching, performance tuning, schema design, index
   recommendations, ORM config, connection pooling, SQL syntax help, N+1
   review, AND migration writing. This is 8+ unrelated jobs in one skill —
   should be split into several narrow skills (e.g. `write-migration`,
   `review-query-performance`), not one sprawling one.
2. **Instructions are non-instructions** — "Just help however seems
   useful" gives Copilot no actual procedure to follow; it's the opposite
   of what SKILL.md instructions should do.
3. **Hardcoded production credential** in `run-migration.js`
   (`postgres://admin:changeme123@prod-db.internal...`) — this is a
   security-blocking finding on its own, separate from the
   interactivity issue, and should trigger a **Governance Gate** flag
   given it's a script that can write to a production database.
4. **`references/notes.md` is nearly content-free** — technically exists
   (passes the script's existence check) but doesn't justify being split
   out from SKILL.md; a reviewer should flag that it isn't doing the job
   `references/` is for.

### Correct Verdict
**Needs Governance Gate review** (due to the hardcoded prod credential and
a script capable of running migrations against production) — not merely
"needs fixes." A candidate who marks this "needs fixes" but misses the
Governance Gate implication has not passed this kata.
