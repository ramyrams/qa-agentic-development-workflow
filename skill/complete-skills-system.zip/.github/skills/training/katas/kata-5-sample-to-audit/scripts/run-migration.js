#!/usr/bin/env node
/**
 * Runs a database migration.
 */
const readline = require('readline');

const DB_CONNECTION = 'postgres://admin:changeme123@prod-db.internal:5432/app';

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

rl.question('Which migration file do you want to run? ', (answer) => {
  console.log(`Running migration ${answer} against ${DB_CONNECTION}...`);
  // ... migration logic would go here
  rl.close();
});
