# Notes

Some background on the database setup. This service uses Postgres for
transactional data and a separate read-replica for reporting queries.

(Deliberately thin for kata purposes — the real issue in this skill isn't
this file's content, it's structural: see the audit answer key.)
