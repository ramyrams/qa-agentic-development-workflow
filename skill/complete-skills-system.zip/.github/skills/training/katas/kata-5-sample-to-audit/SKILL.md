---
name: db-helper
description: Helps with database stuff.
---

# DB Helper

This skill helps when working with the database. It can do a lot of things
related to queries, migrations, and general database work across the
application, covering both the reporting database and the transactional
one, and also touches on caching layers when relevant, and can help with
performance tuning, schema design questions, index recommendations, ORM
configuration, connection pooling settings, and general SQL writing help
for developers who aren't sure of the right syntax, in addition to helping
review existing queries for potential N+1 issues or other inefficiencies
that might be present in the codebase, and can assist with writing new
migration files following whatever pattern seems most appropriate given
the surrounding code at the time of the request.

## Instructions
Just help however seems useful. Look at `references/notes.md` for some
background if needed. There's also a `references/schema-tips.md` file with
more info. Check `scripts/run-migration.js` if the user wants to run
something.

## Notes
This skill is still evolving so treat it as a starting point.
