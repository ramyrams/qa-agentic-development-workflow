# Kata 1 (User): Triggering Literacy

**Level:** User → Author gate (part 1)
**Time box:** 20 minutes
**Materials:** the three shipped skills — `add-rest-endpoint`, `pr-review`,
`audit-skill-quality`.

## Task
For each scenario below, state:
1. Which skill (if any) should trigger
2. The exact phrase in that skill's `description` that justifies your answer
3. If no skill should trigger, say so and explain why

## Scenarios
1. "Add a DELETE endpoint for /orders/:id"
2. "Can you check this PR before I ask Sam to review it?"
3. "I wrote a new skill for generating changelogs — is it ready to add to
   our catalog?"
4. "Write a GraphQL resolver for fetching a user's order history"
5. "This route works but I'm not sure the error handling is right"
6. "We keep writing the same three Cypress helpers by hand — should this be
   a skill?"

## Definition of Done
6/6 correct, including scenario 4 (a trick question — no skill covers
GraphQL, `add-rest-endpoint`'s description explicitly excludes it) and
scenario 6 (also a trick — this is a *proposal* to create a skill, not a
task for an existing one; correctly identifying "none of these, this is a
new-skill proposal" is the right answer).

## Grader Notes
Scenario 3 tests whether the candidate knows `audit-skill-quality` exists
and is the right tool — a common failure is defaulting to `pr-review`
because "review" is in both prompts. Watch for that specific confusion.
