# Kata 2 (Author): Minimal Skill, Real Problem

**Level:** Author gate (part 1 of 3)
**Time box:** 1-2 hours
**Materials:** your own team's repo — this kata explicitly requires a real,
current friction point, not a synthetic example.

## Task
1. Identify one recurring, describable task on your team that currently has
   no skill — something you or a teammate does by re-explaining the same
   context to Copilot each time (a specific lint config, a naming
   convention, a repeated debugging approach — anything real).
2. Write a **SKILL.md-only** skill (no `references/`, `assets/`, or
   `scripts/` yet — that's Kata 3). Keep it under 100 lines.
3. Test it: actually invoke Copilot with 2-3 prompts that should trigger it
   and 1 prompt that deliberately shouldn't, and record what happened.

## Definition of Done
- `node .github/skills/audit-skill-quality/scripts/audit-skill.js
  <your-skill-path>` returns clean (no blocking findings).
- Description names at least 2 concrete trigger phrases.
- Your 2-3 positive test prompts actually triggered the skill; your
  negative test prompt did not.
- Submitted with your test transcript, not just the SKILL.md — "it should
  trigger on X" without having tried X doesn't count.

## Common Failure Modes to Watch For
- Description too generic ("helps with formatting") — the #1 reason skills
  don't fire.
- Skill scoped to a task that's actually two unrelated tasks — a sign it
  should be two skills later, or narrowed now.
- Skipping the negative test — a skill that triggers on everything is as
  broken as one that never triggers.
