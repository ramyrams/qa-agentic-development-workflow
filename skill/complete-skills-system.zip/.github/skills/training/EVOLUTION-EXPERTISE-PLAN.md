# Implementation Plan: Skill Evolution Expertise

**Scope note:** "Skill evolution" here means the competency of safely extending,
versioning, re-validating, and retiring skills *after* they first ship —
distinct from authoring (Phase 1 of the original expertise plan) and from
governance policy (the Governance Model). This is the discipline behind
Kata 4, `MAINTENANCE.md`, `DETERMINISM-FRAMEWORK.md`'s regression
protection, and `skill-health-report` — formalized into a rollout plan
with real milestones.

**Audience:** you first (Architect-level depth), then rolled to the team
via the existing `COMPETENCY-LADDER.md`.

---

## Phase A — Evolution Foundations (Week 1–2)

**Objective:** internalize why skills drift over time and the vocabulary
for talking about it precisely, before touching real changes.

| Deliverable | Detail |
|---|---|
| Versioning fluency | Cold-read `MAINTENANCE.md`; then classify 10 hypothetical changes (provided below) as MAJOR/MINOR/PATCH with justification |
| Drift vocabulary | Read `DETERMINISM-FRAMEWORK.md` fully; be able to explain, unprompted, why a Tier 3 (open-judgment) step needs a Tier 1 validator |
| Real precedent review | Read the `validate-endpoint.js` false-negative incident (the commented-out `requireAuth` bug caught by golden tests) as a case study — this is the reference example for "why regression tests on validators, not just generators, matter" |

**Practice exercise — versioning classification (do this, don't just read):**
1. A skill's description gains a new trigger phrase for a scenario it already handled → ?
2. A skill's `references/` file is corrected for a factual error, no behavior change → ?
3. A skill's script gains a new `--dry-run` flag, default behavior unchanged → ?
4. A skill that previously only read files now has a script that writes a file → ?
5. A typo fix in SKILL.md prose → ?
6. A skill's trigger conditions are narrowed to stop false-triggering → ?
7. A new `references/` file is added covering an edge case the skill already claimed to handle → ?
8. A skill's script changes from writing to a local file to calling an external API → ?
(Answers: 1-MINOR, 2-PATCH, 3-MINOR, 4-MAJOR — also triggers risk reclassification per the Governance Model, 5-PATCH, 6-MINOR or MAJOR depending on whether it drops real coverage — discuss, 7-MINOR, 8-MAJOR — also mandatory Governance Gate re-review.)

**Exit criteria:** can classify a real change correctly without checking the
reference doc, and can state which changes also trigger a Governance Gate
re-review (per the Governance Model's reclassification rule).

---

## Phase B — Safe Extension Practice (Week 3–4)

**Objective:** extend a real, already-shipped skill without breaking it or
silently increasing drift — this is Kata 4, done for real rather than as
an exercise.

| Step | Detail |
|---|---|
| 1. Pick a real gap | In an already-shipped skill (`add-rest-endpoint`, `pr-review`, or `audit-skill-quality`), identify one real missing scenario from actual usage or `FEEDBACK.md` |
| 2. Re-run existing golden tests first | Before changing anything, run `tests/run-golden-tests.js` (or write one if the skill lacks it) to capture the current passing baseline |
| 3. Make the extension | Add the capability; this should be a MINOR bump per the Phase A rules |
| 4. Re-run golden tests | Confirm the baseline scenarios still pass — if any fail, the "extension" was actually a behavior change and needs to be MAJOR or reworked |
| 5. Add a new golden scenario | Covering the new capability, so the next person's extension is checked against this one too |
| 6. Update `CATALOG.md` | Version bump, `Last Audited` date, confirm `audit-skill-quality` still passes clean |

**Deliverable:** one real, merged extension with before/after golden-test
output attached — not a description of what would happen.

**Exit criteria:** a second Architect-level reviewer confirms the version
bump was classified correctly and the regression test actually would have
caught a plausible mistake (verify by deliberately breaking the change
locally and confirming the test fails, then fixing it — same method used
to validate `validate-endpoint.js`'s fix).

---

## Phase C — Audit & Health-Review Ownership (Week 5–6)

**Objective:** run a full quarterly cycle end-to-end, including the
judgment calls a script can't make.

| Step | Detail |
|---|---|
| 1. Run `audit-skill-quality` | Against every catalog skill; record findings |
| 2. Run `skill-health-report` | Against real (or, if volume is low this early, backfilled realistic) `FEEDBACK.md` entries |
| 3. Apply `references/health-review-process.md` | Turn flags into actual decisions — fix, retire, keep, or reclaim ownership |
| 4. Fill `assets/health-review-template.md` | Completely, including the "Notes for Next Quarter" section |
| 5. Update `CATALOG.md` and `FEEDBACK.md` | Per the decisions — version bumps, status changes, archived entries |

**Deliverable:** one completed `health-review-template.md` for the current
quarter, covering the full real catalog.

**Exit criteria:** at least one skill in the review has a defensible
"keep despite low usage" or "retire despite no complaints" decision — this
is the check that the candidate isn't just mechanically following flags
(see `references/health-review-process.md`'s "silence isn't necessarily
success" guidance).

---

## Phase D — Retirement and Ownership Transfer (Week 7)

**Objective:** practice the two lifecycle events that are rare enough to
be unfamiliar when they actually matter.

| Step | Detail |
|---|---|
| 1. Retirement | Pick a genuinely obsolete or duplicated skill (real, or simulate with a training skill); follow `MAINTENANCE.md`'s retirement steps exactly — `CATALOG.md` row kept with `Retired` status and reason, folder removed |
| 2. Ownership transfer | Practice the one-line `CATALOG.md` PR described in `MAINTENANCE.md`; confirm the new owner actually reviewed the skill's current state before accepting, not just accepting the role nominally |
| 3. Orphan handling | Given a skill whose owner has left the team (simulate), correctly apply the "treated as Deprecated until reclaimed" rule and set a resolution deadline |

**Exit criteria:** can execute both without looking up the process from
scratch, and can articulate *why* retirement keeps the `CATALOG.md` row
(history) rather than deleting it outright.

---

## Phase E — Architect-Level Evolution Judgment (Week 8+, ongoing)

**Objective:** sustained, real ownership — this phase doesn't end, it
becomes the job.

| Responsibility | Cadence |
|---|---|
| Own quarterly health review for an assigned slice of the catalog | Quarterly, per `MAINTENANCE.md` |
| Mentor an Author-level teammate through their first real extension | As needed, tied to `COMPETENCY-LADDER.md` promotions |
| Handle at least one MAJOR-version reclassification end-to-end (capability change → Governance Gate routing → re-audit → catalog update) | As it arises |
| Review a peer's retirement/extension decision (second-reviewer role from Phase B/D) | As it arises |

**Promotion tie-in:** completing Phases A–D, plus one live Phase E cycle,
satisfies the Architect-level "one real skill shipped to the catalog with
a clean audit" bar in `COMPETENCY-LADDER.md` specifically for the
evolution/maintenance competency — authoring expertise (original Phase 1)
and evolution expertise are tracked as related but separate demonstrations,
since a strong author is not automatically a safe maintainer.

---

## Timeline Summary

| Week | Phase | Primary Output |
|---|---|---|
| 1–2 | A: Foundations | Versioning classification exercise, passed |
| 3–4 | B: Safe Extension | One real merged extension with regression proof |
| 5–6 | C: Audit & Health Review | One completed quarterly health review |
| 7 | D: Retirement & Transfer | One retirement, one ownership transfer, executed |
| 8+ | E: Ongoing Ownership | ongoing — ownership assignment, mentoring, ad hoc reclassifications |

## Rollout to the Team

Once you've completed Phases A–D personally:
1. Run Phase A as a group session (the 8-question classification exercise
   works well as a live discussion, similar to Kata 6's paired-review
   format).
2. Assign Phase B extensions individually, paired with a second reviewer
   per the exit criteria.
3. Rotate Phase C ownership quarterly across Architect-level team members
   rather than concentrating it on one person — this is itself a
   safeguard against the "silent single point of failure" risk that
   `MAINTENANCE.md`'s single-owner rule is designed to avoid at the
   individual-skill level.

## Dependencies
- Requires `MAINTENANCE.md`, `DETERMINISM-FRAMEWORK.md`, `CATALOG.md`,
  `FEEDBACK.md`, `skill-health-report`, and `audit-skill-quality` already
  in place (all shipped).
- Requires at least one quarter of real `FEEDBACK.md` data for Phase C to
  be meaningful — if the catalog is too new, backfill Phase C with
  realistic synthetic data (as used to validate `generate-health-report.js`)
  and flag results as practice, not a real decision record.
