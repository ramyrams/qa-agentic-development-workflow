# Skill Competency Ladder

Three levels. Promotion between levels is earned by passing the katas in
`katas/`, graded against `GRADING-RUBRIC.md` — not by tenure or self-report.

## Level 1 — User
**Can:** recognize which existing skill applies to a task, read a SKILL.md
and correctly predict when it will/won't trigger, invoke a skill's bundled
scripts correctly from its Quick Start section.
**Cannot yet:** write a new skill unsupervised.
**Promotion gate:** Kata 1.

## Level 2 — Author
**Can:** design and write a single, well-scoped skill — correct frontmatter,
a description with real trigger phrases, correct use of `references/` vs
`assets/` vs `scripts/`, and a skill that passes `audit-skill-quality`'s
mechanical checks without hand-holding.
**Cannot yet:** be trusted to judge governance risk alone, or own the
catalog's overall health.
**Promotion gate:** Kata 2, Kata 3, and Kata 4 (extending an existing skill
without breaking it).

## Level 3 — Architect
**Can:** audit someone else's skill and produce a correct, defensible
scorecard (including catching qualitative issues a script can't); decide
whether a proposed skill duplicates the catalog or deserves to exist
standalone; correctly flag governance risk; own re-audit cadence and
versioning for a set of skills.
**Promotion gate:** Kata 5 and Kata 6, plus one real skill shipped to the
shared catalog with a clean audit.

## Ladder Is Not One-Way
An Architect who stops maintaining their owned skills (misses re-audits,
lets `CATALOG.md` rows go stale) should be re-evaluated at Author level for
that skill — competency here is about current practice, not a permanent
credential.
