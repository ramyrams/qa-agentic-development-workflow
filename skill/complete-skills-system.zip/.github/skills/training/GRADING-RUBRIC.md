# Grading Rubric

How katas map to promotion decisions on the `COMPETENCY-LADDER.md`. Graders
should be at least one level above the candidate (an Author grades User
promotion; an Architect grades Author promotion; Architect-to-Architect
review, e.g. a second Architect, confirms Architect-level work).

## User → Author (Kata 1)
Pass/fail, objective — 6/6 scenarios correct per the kata's own key.
No partial credit: a missed trigger in production has the same cost whether
the candidate got 5/6 or 3/6 right in the kata.

## Author Promotion (Kata 2 + 3 + 4)
Each kata individually pass/fail against its own Definition of Done. All
three required — a candidate strong at writing (Kata 2/3) but weak at
extending safely (Kata 4) is not yet ready to be trusted on shared catalog
skills, since most ongoing work is extension.

Use `audit-skill-quality`'s own `assets/audit-scorecard.md` as the actual
grading artifact for Kata 3 — don't invent a separate form. This is
intentional: candidates should get fluent with the real tool they'll use
on the job, not a training-only proxy for it.

## Architect Promotion (Kata 5 + 6 + one shipped skill)
- **Kata 5** is pass/fail against the fixed answer key. A candidate who
  matches the script's mechanical findings but misses the qualitative ones
  (scope, non-instructions, hardcoded credential) has not passed — the
  entire point of Architect level is catching what tooling can't.
- **Kata 6** is graded on reasoning, reviewed live by a second
  Architect-level person. Document disagreements — they're useful input
  for revising `MAINTENANCE.md` if the same ambiguity keeps coming up.
- **One real skill shipped to the catalog with a clean audit** is required
  in addition to both katas — Architect level is demonstrated on real
  stakes, not just exercises.

## Re-Grading and Appeals
If a candidate disagrees with a kata result, a second grader at the
relevant level re-grades independently before any discussion between
grader and candidate — avoids anchoring the second opinion on the first.

## Cadence
Run Kata 1 as part of onboarding for anyone touching `.github/skills/`,
even if they're not expected to author skills soon — trigger literacy is
cheap to build and prevents wasted Copilot sessions.
