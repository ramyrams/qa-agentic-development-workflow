#!/usr/bin/env node
/**
 * Mechanical pre-review checks across one or more changed files.
 * Catches grep-able mistakes so review time goes to judgment calls.
 *
 * Usage:
 *   node run-static-checks.js <file1> <file2> ...
 */
const fs = require('fs');

const files = process.argv.slice(2);
if (!files.length) {
  console.error('Usage: node run-static-checks.js <file1> [file2 ...]');
  process.exit(1);
}

const rules = [
  {
    id: 'no-console-log',
    test: /console\.(log|debug)\(/,
    severity: 'blocking',
    message: 'console.log/debug left in code — use the project logger.',
  },
  {
    id: 'no-empty-catch',
    test: /catch\s*\([^)]*\)\s*\{\s*\}/,
    severity: 'blocking',
    message: 'Empty catch block — handle, rethrow, or log with context.',
  },
  {
    id: 'no-hardcoded-secret',
    test: /(api[_-]?key|secret|password|token)\s*[:=]\s*['"][A-Za-z0-9+/_=-]{8,}['"]/i,
    severity: 'blocking',
    message: 'Possible hardcoded secret — move to environment config.',
  },
  {
    id: 'no-raw-req-body',
    test: /req\.body\b/,
    severity: 'blocking',
    message: 'Direct req.body access — validate and use req.validated instead.',
  },
  {
    id: 'no-any-type',
    test: /:\s*any\b/,
    severity: 'suggestion',
    message: 'Explicit `any` type — consider a narrower type if feasible.',
  },
  {
    id: 'todo-without-ticket',
    test: /\/\/\s*TODO(?!.*[A-Z]+-\d+)/,
    severity: 'nitpick',
    message: 'TODO without a ticket reference (e.g. TODO(PROJ-123): ...).',
  },
];

let totalFindings = 0;
const severityOrder = { blocking: 0, suggestion: 1, nitpick: 2 };

for (const file of files) {
  if (!fs.existsSync(file)) {
    console.warn(`⚠️  Skipping ${file} — not found`);
    continue;
  }
  const content = fs.readFileSync(file, 'utf8');
  const findings = rules.filter((r) => r.test.test(content));

  if (!findings.length) {
    console.log(`✅ ${file} — no mechanical findings`);
    continue;
  }

  totalFindings += findings.length;
  console.log(`\n${file}:`);
  findings
    .sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity])
    .forEach((f) => {
      const icon = { blocking: '🔴', suggestion: '🟡', nitpick: '⚪' }[f.severity];
      console.log(`  ${icon} [${f.severity}] ${f.message}`);
    });
}

console.log(`\n${totalFindings} mechanical finding(s) across ${files.length} file(s).`);
console.log('Now check references/review-standards.md and security-checklist.md for the rest.');

process.exit(totalFindings > 0 ? 1 : 0);
