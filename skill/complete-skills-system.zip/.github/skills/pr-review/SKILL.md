---
name: pr-review
description: >
  Review a pull request or local diff against this team's coding standards
  before approval — style, error-handling conventions, security basics, and
  test coverage. Use when asked to "review this PR", "review my diff",
  "check this code before I push", or "is this ready for review". Covers
  backend/API TypeScript changes in this repo.
argument-hint: "PR number, branch name, or list of changed files to review"
---

# PR Review

## When to Use
- Before opening a PR, as a self-check
- Reviewing a teammate's PR
- Reviewing AI-generated code before it ships (this is the primary defense
  against convention drift when [[add-rest-endpoint]] or similar skills
  generate code)

## Quick Start
```bash
node .github/skills/pr-review/scripts/run-static-checks.js <file1> <file2> ...
```
Then walk the findings against `references/review-standards.md` and
`references/security-checklist.md` for anything the script can't catch
mechanically (naming clarity, whether the abstraction is right, whether
tests actually assert the right thing).

## Instructions

1. **Run the static checker first.** It catches mechanical violations
   (console.log left in, empty catch blocks, obvious secret patterns) so you
   spend review time on judgment calls, not grep-able mistakes.
2. **Load `references/review-standards.md`** for the non-mechanical checks:
   naming, structure, adherence to this repo's error-handling and response
   conventions.
3. **Load `references/security-checklist.md`** for any change touching auth,
   input handling, or external calls — skip it for pure refactors with no
   behavior change.
4. **Use `assets/review-comment-templates.md`** to phrase findings —
   severity-tagged (blocking / suggestion / nitpick) so the author knows
   what must change vs. what's optional.
5. **Never approve silently.** Every review produces either a list of
   findings or an explicit "no blocking issues found" — don't just say
   "looks good" without stating what was checked.
6. If the diff touches a pattern this skill doesn't cover (e.g. database
   migrations, infra config), say so explicitly rather than reviewing it
   against the wrong checklist.

## Output
A findings list grouped by severity, each tagged with the relevant standard
or checklist item it violates, using the templates in `assets/`.
