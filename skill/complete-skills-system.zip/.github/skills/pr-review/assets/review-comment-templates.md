# Review Comment Templates

Use these to phrase findings consistently. Fill in the bracketed parts.

## Blocking
> 🔴 **Blocking:** [what's wrong]. This [violates convention / creates risk
> because...]. See `[reference file]` for the expected pattern.
> Suggested fix: [concrete fix, not just "fix this"].

## Suggestion
> 🟡 **Suggestion:** [what could be better]. Not blocking, but consider
> [alternative] because [brief reason].

## Nitpick
> ⚪ **Nitpick:** [minor style point]. Optional — your call.

## Approval with no blocking issues
> ✅ Reviewed against `review-standards.md` and `security-checklist.md`
> (if applicable). No blocking issues found. [N suggestions / nitpicks
> below, all optional.]

## Missing Test Coverage
> 🔴 **Blocking:** [Function/route] has no test covering [the specific
> behavior]. A test that would fail if this logic were reverted is required
> before merge.

## Security Finding
> 🔴 **Blocking (security):** [specific issue, e.g. "raw req.params.id used
> in query without validation"]. See `security-checklist.md` → [section].
> This must be fixed before merge, not deferred to a follow-up.
