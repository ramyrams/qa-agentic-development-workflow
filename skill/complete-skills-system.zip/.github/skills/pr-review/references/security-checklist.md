# Security Checklist Reference

Load this when the diff touches auth, input handling, external calls, or
data storage. Skip for pure refactors with no behavior change.

## Input Handling
- All external input validated via the `validate(schema)` middleware —
  never trust `req.params`, `req.query`, or `req.body` directly.
- No string concatenation into SQL — parameterized queries / ORM only.
- File uploads validated for type and size before processing.

## Auth
- Every non-public route has `requireAuth` (or an explicit, reviewed reason
  it doesn't).
- Authorization checked, not just authentication — a logged-in user isn't
  automatically allowed to act on any resource ID they pass in.

## Secrets
- No hardcoded API keys, tokens, or credentials — even in test files or
  comments.
- No secrets logged, including in error messages or stack traces sent to
  clients.

## External Calls
- Timeouts set on all outbound HTTP calls.
- Responses from external services validated before use, not trusted
  blindly.

## Flag, Don't Fix
This checklist is for flagging findings during review — do not silently
"fix" a security issue found in someone else's PR without calling it out
explicitly as a blocking comment first.
