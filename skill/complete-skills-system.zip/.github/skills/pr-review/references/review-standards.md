# Review Standards Reference

These extend (not replace) `add-rest-endpoint`'s conventions — a PR that
generated its endpoint from that skill should already pass most of this.

## Structure
- Business logic lives in the service layer, not the controller. A
  controller doing more than validate → call service → shape response is a
  blocking finding.
- No duplicated logic across controllers — if the same 5+ lines appear
  twice, it should be extracted.

## Error Handling
- Errors thrown as `ApiError`, not hand-built `res.status().json()` (see
  `add-rest-endpoint/references/error-handling-patterns.md`).
- No empty `catch {}` blocks — every catch either handles, rethrows, or logs
  with context.
- No swallowed promise rejections (missing `await`, missing `asyncHandler`).

## Naming & Readability
- Function names describe what they do, not how (`getActiveOrders`, not
  `filterAndMap`).
- No single-letter variables outside of loop indices.
- Magic numbers extracted to named constants.

## Tests
- New logic has a test that would fail if the logic were reverted — not
  just a test that exercises the code path.
- Mocks are scoped to the test file, not leaking global state between tests.

## Severity Guide
| Severity | Meaning |
|---|---|
| Blocking | Must fix before merge (security, correctness, convention violation with real impact) |
| Suggestion | Should probably fix, author's call |
| Nitpick | Style preference, non-blocking, optional |
