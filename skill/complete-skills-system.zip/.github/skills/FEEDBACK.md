# Skill Feedback Log

Copilot's skill system has no built-in telemetry on whether a skill
triggered correctly — this log is the substitute. Anyone who hits a
triggering problem or has a strong reaction to a skill's output logs it
here. `skill-health-report` reads this file to surface patterns.

**Log an entry any time you notice:**
- A skill should have triggered and didn't (missed trigger)
- A skill triggered when it shouldn't have (false trigger)
- A skill triggered correctly but its instructions/output were wrong
  (bug)
- A skill worked well and saved real time (praise — useful signal too;
  don't only log complaints)

Keep entries to one line. Don't edit or delete others' entries — add a new
row. `skill-health-report` cleans up/archives on its own cadence.

| Date | Skill | Reporter | Type | Details |
|---|---|---|---|---|
<!-- Add rows below. Example format (delete once real entries exist):
| 2026-08-20 | add-rest-endpoint | jsmith | missed-trigger | Asked "add a route for cancelling orders" — didn't fire, had to say "add an endpoint" explicitly |
| 2026-08-22 | pr-review | agupta | praise | Caught an empty catch block I would have missed |
-->
