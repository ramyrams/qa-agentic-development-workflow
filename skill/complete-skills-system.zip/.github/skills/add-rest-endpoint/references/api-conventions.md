# API Conventions Reference

This file is loaded by Copilot only when `add-rest-endpoint` is active — it's
where the detailed, rarely-changing rules live so SKILL.md stays short.

## Routing
- Resource paths are plural, kebab-case: `/orders`, `/shipping-labels`.
- Nested resources: `/orders/:orderId/line-items`.
- Route files live in `src/routes/<resource>.routes.ts`; controller logic in
  `src/controllers/<resource>.controller.ts`. Do not put business logic in
  the route file itself.

## Request Validation
- Every route uses the `validate(schema)` middleware from
  `src/middleware/validate.ts` — never read `req.body` directly in a
  controller. After validation, use `req.validated`.
- Schemas live in `src/schemas/<resource>.schema.ts` using Zod.

## Response Shape
All success responses use the envelope:
```json
{ "data": { ... }, "meta": { "requestId": "..." } }
```
List endpoints add a `pagination` object inside `meta`. Never return a bare
array or bare object at the top level.

## Naming
- Controller methods: `list`, `get`, `create`, `update`, `remove` (not
  `delete` — reserved word friction in some tooling).
- Route constants use `SCREAMING_SNAKE_CASE` in `src/routes/constants.ts`.

## Auth
- Default to requiring the `requireAuth` middleware unless the route is
  explicitly public (rare — confirm with the user before omitting it).
