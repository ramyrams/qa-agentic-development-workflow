# Error Handling Patterns Reference

## Standard Error Flow
Controllers never call `res.status(...).json(...)` for errors. Instead:

```ts
import { ApiError } from '../errors/ApiError';

if (!order) {
  throw new ApiError(404, 'ORDER_NOT_FOUND', 'Order not found');
}
```

`ApiError` is caught by the global error middleware in
`src/middleware/errorHandler.ts`, which shapes the response as:
```json
{ "error": { "code": "ORDER_NOT_FOUND", "message": "Order not found" } }
```

## Common Error Codes
| HTTP Status | Code prefix | Example |
|---|---|---|
| 400 | `VALIDATION_` | `VALIDATION_INVALID_STATUS` |
| 404 | `<RESOURCE>_NOT_FOUND` | `ORDER_NOT_FOUND` |
| 409 | `<RESOURCE>_CONFLICT` | `ORDER_ALREADY_SHIPPED` |
| 500 | never custom-coded | let it bubble to default handler |

## Async Handlers
Wrap all async route handlers with `asyncHandler()` from
`src/middleware/asyncHandler.ts` so rejected promises reach the error
middleware instead of hanging the request.
