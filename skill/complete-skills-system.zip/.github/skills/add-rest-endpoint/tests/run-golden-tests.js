#!/usr/bin/env node
/**
 * Regression harness for add-rest-endpoint's Tier 1 generation.
 *
 * Runs generate-scaffold.js against every fixed scenario in
 * golden-scenarios.json, then runs validate-endpoint.js against the
 * result. If a SKILL.md or template edit silently breaks generation or
 * introduces a convention violation, this catches it before it reaches a
 * real developer.
 *
 * Usage:
 *   node run-golden-tests.js
 *
 * Runs in a scratch directory so it never touches real repo files.
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const skillDir = path.join(__dirname, '..');
const scenariosPath = path.join(__dirname, 'golden-scenarios.json');
const scenarios = JSON.parse(fs.readFileSync(scenariosPath, 'utf8'));

const scratchDir = fs.mkdtempSync(path.join(require('os').tmpdir(), 'golden-test-'));
console.log(`Scratch dir: ${scratchDir}\n`);

let failures = 0;

for (const scenario of scenarios) {
  const label = `${scenario.method.toUpperCase()} /${scenario.path}`;
  process.stdout.write(`${label} ... `);

  try {
    execFileSync(
      'node',
      [
        path.join(skillDir, 'scripts', 'generate-scaffold.js'),
        '--method', scenario.method,
        '--resource', scenario.resource,
        '--path', scenario.path,
      ],
      { cwd: scratchDir, stdio: 'pipe' }
    );

    const resource = scenario.resource[0].toLowerCase() + scenario.resource.slice(1);
    const routeFile = path.join(scratchDir, 'src', 'routes', `${resource}.${scenario.method}.generated.ts`);

    if (!fs.existsSync(routeFile)) {
      throw new Error(`Expected generated file not found: ${routeFile}`);
    }

    execFileSync(
      'node',
      [path.join(skillDir, 'scripts', 'validate-endpoint.js'), routeFile],
      { cwd: scratchDir, stdio: 'pipe' }
    );

    console.log('✅ pass');
  } catch (err) {
    failures++;
    console.log('❌ FAIL');
    console.log(`   ${err.message.split('\n')[0]}`);
    if (err.stdout) console.log(`   ${err.stdout.toString().trim().split('\n').join('\n   ')}`);
    if (err.stderr) console.log(`   ${err.stderr.toString().trim().split('\n').join('\n   ')}`);
  }
}

fs.rmSync(scratchDir, { recursive: true, force: true });

console.log(`\n${scenarios.length - failures}/${scenarios.length} golden scenarios passed.`);
process.exit(failures > 0 ? 1 : 0);
