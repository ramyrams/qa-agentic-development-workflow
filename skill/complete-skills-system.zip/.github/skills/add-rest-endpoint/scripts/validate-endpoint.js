#!/usr/bin/env node
/**
 * Static checks that catch the most common ways a hand-edited endpoint
 * drifts from team conventions. Not a replacement for tests — a fast
 * pre-review gate.
 *
 * Usage:
 *   node validate-endpoint.js src/routes/order.post.generated.ts
 */
const fs = require('fs');

const file = process.argv[2];
if (!file) {
  console.error('Usage: node validate-endpoint.js <route-file>');
  process.exit(1);
}

const rawContent = fs.readFileSync(file, 'utf8');
const errors = [];

// Strip comments before checking "is this actually used" patterns — a
// bare substring/regex match can't tell a real usage from a mention in an
// import line or a commented-out line, which caused a real false negative
// here (caught by tests/run-golden-tests.js: a commented-out requireAuth
// call still matched `/requireAuth/` because the import line and the
// comment both contain the word). Checks below that must confirm active
// *usage* run against `activeContent`; checks that only need to detect a
// literal pattern regardless of comments keep using `rawContent`.
const activeContent = rawContent
  .split('\n')
  .map((line) => line.replace(/\/\/.*$/, '')) // strip line comments
  .join('\n');

const checks = [
  {
    test: /req\.body\b/,
    content: rawContent,
    shouldMatch: false,
    message: 'Uses req.body directly — read req.validated after the validate() middleware instead.',
  },
  {
    test: /res\.status\(\d+\)\.json\(\{\s*error/,
    content: rawContent,
    shouldMatch: false,
    message: 'Hand-rolls an error response — throw ApiError and let errorHandler middleware format it.',
  },
  {
    // Must appear as an active call in the middleware chain, not just an
    // import or a comment — require it followed by a comma/paren as it
    // would be when passed to router.<method>(...).
    test: /\brequireAuth\s*[,)]/,
    content: activeContent,
    shouldMatch: true,
    message: 'No active requireAuth middleware call found — confirm this route is intentionally public.',
  },
  {
    test: /asyncHandler\(/,
    content: activeContent,
    shouldMatch: true,
    message: 'Async route handler is not wrapped in asyncHandler() — rejected promises will hang.',
  },
  {
    test: /meta:\s*\{\s*requestId/,
    content: activeContent,
    shouldMatch: true,
    message: 'Success response is missing the meta.requestId envelope field.',
  },
];

for (const check of checks) {
  const matched = check.test.test(check.content);
  if (matched !== check.shouldMatch) {
    errors.push(check.message);
  }
}

if (errors.length) {
  console.error(`❌ ${errors.length} issue(s) found in ${file}:\n`);
  errors.forEach((e) => console.error(`  - ${e}`));
  process.exit(1);
}

console.log(`✅ ${file} passes convention checks.`);
