#!/usr/bin/env node
/**
 * Generates a route, test, and OpenAPI fragment from the templates in
 * ../assets/ by substituting {{placeholders}}.
 *
 * Usage:
 *   node generate-scaffold.js --method post --resource Order --path orders
 *
 * This script is executed directly by Copilot — its output (file paths
 * written) is what gets returned to the model, not the script body itself,
 * which keeps token usage low for a mechanical templating step.
 */
const fs = require('fs');
const path = require('path');

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 2) {
    out[argv[i].replace(/^--/, '')] = argv[i + 1];
  }
  return out;
}

const args = parseArgs(process.argv.slice(2));
const required = ['method', 'resource', 'path'];
for (const r of required) {
  if (!args[r]) {
    console.error(`Missing required --${r}`);
    process.exit(1);
  }
}

const method = args.method.toLowerCase();
const Resource = args.resource[0].toUpperCase() + args.resource.slice(1);
const resource = args.resource[0].toLowerCase() + args.resource.slice(1);
const RESOURCE = args.resource.toUpperCase();
const resourcePath = args.path.replace(/^\//, '');
const action = { post: 'create', get: 'get', put: 'update', delete: 'remove' }[method] || 'handle';

const replacements = {
  '{{method}}': method,
  '{{Resource}}': Resource,
  '{{resource}}': resource,
  '{{RESOURCE}}': RESOURCE,
  '{{resource-path}}': resourcePath,
  '{{action}}': action,
  '{{Action description}}': `${action} ${Resource}`,
};

function render(templatePath) {
  let content = fs.readFileSync(templatePath, 'utf8');
  for (const [k, v] of Object.entries(replacements)) {
    content = content.split(k).join(v);
  }
  return content;
}

const assetsDir = path.join(__dirname, '..', 'assets');
const outputs = [
  {
    template: 'endpoint.template.ts',
    out: `src/routes/${resource}.${method}.generated.ts`,
  },
  {
    template: 'endpoint.test.template.ts',
    out: `src/routes/__tests__/${resource}.${method}.generated.test.ts`,
  },
  {
    template: 'openapi-fragment.template.yaml',
    out: `openapi/paths/${resourcePath}.${method}.fragment.yaml`,
  },
];

for (const { template, out } of outputs) {
  const rendered = render(path.join(assetsDir, template));
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, rendered);
  console.log(`Wrote ${out}`);
}

console.log(
  '\nNext: fill in the TODO business logic, merge the OpenAPI fragment, ' +
    'then run validate-endpoint.js on the new route file.'
);
