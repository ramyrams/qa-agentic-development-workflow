// TEMPLATE — replace {{Resource}}, {{resource}}, {{method}} and fill in logic.
// See references/api-conventions.md and references/error-handling-patterns.md
// before editing this.

import { Router } from 'express';
import { validate } from '../middleware/validate';
import { requireAuth } from '../middleware/requireAuth';
import { asyncHandler } from '../middleware/asyncHandler';
import { ApiError } from '../errors/ApiError';
import { {{resource}}Schema } from '../schemas/{{resource}}.schema';

const router = Router();

router.{{method}}(
  '/{{resource-path}}',
  requireAuth,
  validate({{resource}}Schema),
  asyncHandler(async (req, res) => {
    const input = req.validated;

    // TODO: business logic here — call the service layer, not the DB directly
    const result = await {{resource}}Service.{{action}}(input);

    if (!result) {
      throw new ApiError(404, '{{RESOURCE}}_NOT_FOUND', '{{Resource}} not found');
    }

    res.status(200).json({
      data: result,
      meta: { requestId: req.id },
    });
  })
);

export default router;
