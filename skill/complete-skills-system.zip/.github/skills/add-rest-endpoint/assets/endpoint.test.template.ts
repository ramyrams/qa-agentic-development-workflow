// TEMPLATE — replace {{Resource}}, {{resource}}, {{method}}, {{resource-path}}

import request from 'supertest';
import { app } from '../../app';
import { {{resource}}Service } from '../../services/{{resource}}.service';

jest.mock('../../services/{{resource}}.service');

describe('{{method}} /{{resource-path}}', () => {
  it('returns 200 and the envelope shape on success', async () => {
    ({{resource}}Service.{{action}} as jest.Mock).mockResolvedValue({ id: '1' });

    const res = await request(app).{{method}}('/{{resource-path}}').send({});

    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('data');
    expect(res.body).toHaveProperty('meta.requestId');
  });

  it('returns 404 with standard error shape when not found', async () => {
    ({{resource}}Service.{{action}} as jest.Mock).mockResolvedValue(null);

    const res = await request(app).{{method}}('/{{resource-path}}').send({});

    expect(res.status).toBe(404);
    expect(res.body.error.code).toBe('{{RESOURCE}}_NOT_FOUND');
  });

  it('rejects invalid input with 400', async () => {
    const res = await request(app).{{method}}('/{{resource-path}}').send({ invalid: true });
    expect(res.status).toBe(400);
  });
});
