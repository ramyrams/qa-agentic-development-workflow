---
name: add-rest-endpoint
description: >
  Scaffold a new REST API endpoint for this service following team conventions
  (routing, validation, error handling, tests, OpenAPI docs). Use this when the
  user asks to "add an endpoint", "create a new API route", "add a controller
  method", or describes a new resource that needs CRUD operations exposed over
  HTTP. Covers Express + TypeScript services in this repo.
argument-hint: "HTTP method, route path, and resource name (e.g. POST /orders, Order)"
---

# Add REST Endpoint

## When to Use
- Adding a brand-new route to an existing Express router
- Adding a full CRUD set for a new resource
- Retrofitting an ad-hoc route to match team conventions (validation, error
  shape, tests)

Do NOT use this skill for GraphQL resolvers or gRPC services — those follow a
different pattern (not yet covered by this skill).

## Quick Start
1. Confirm the HTTP method, route path, and resource name with the user if any
   are ambiguous.
2. Read `references/api-conventions.md` for routing/naming/response-shape rules
   before writing code — do not guess at conventions.
3. Copy the templates in `assets/` and fill in the resource-specific parts.
4. Run `scripts/generate-scaffold.js` to create the files in the right
   locations (see Quick Start command below) instead of hand-placing them.
5. Run `scripts/validate-endpoint.js` against the new route file before
   telling the user it's done — it checks for the mistakes this skill exists
   to prevent.

```bash
node .github/skills/add-rest-endpoint/scripts/generate-scaffold.js \
  --method POST --resource Order --path /orders
```

## What It Does
| Step | Action | Purpose |
|------|--------|---------|
| 1 | Load `references/api-conventions.md` | Get routing, naming, and response-shape rules |
| 2 | Load `references/error-handling-patterns.md` | Ensure errors use the team's standard error middleware, not ad-hoc `res.status()` calls |
| 3 | Generate route handler from `assets/endpoint.template.ts` | Consistent controller shape |
| 4 | Generate test file from `assets/endpoint.test.template.ts` | No endpoint ships without a test |
| 5 | Generate OpenAPI fragment from `assets/openapi-fragment.template.yaml` | Keep API docs in sync automatically |
| 6 | Run `scripts/validate-endpoint.js` | Catch missing validation, missing error handling, or non-conforming response shape before review |

## Instructions

1. **Never skip the reference docs.** Route conventions here are specific to
   this codebase (e.g. plural resource names, `req.validated` not `req.body`
   after middleware) — general REST knowledge will produce code that fails
   review.
2. **Always generate a test alongside the route.** Use
   `assets/endpoint.test.template.ts` as the base; do not hand-roll test
   structure.
3. **Always update the OpenAPI fragment.** Merge the generated fragment into
   `openapi/paths/*.yaml` — do not leave new routes undocumented.
4. **Run validation before declaring done.** If
   `scripts/validate-endpoint.js` reports errors, fix them; do not report the
   task complete with open validation failures.
5. If the resource already has some CRUD methods implemented, only scaffold
   the missing method(s) — read the existing router file first to avoid
   duplicating routes.

## Output
A new/updated route file wired into the resource's router, a matching test
file, an OpenAPI fragment ready to merge, and a clean validation run.
