#!/usr/bin/env node
/**
 * Parses .github/skills/FEEDBACK.md and .github/skills/CATALOG.md,
 * flags skills needing attention in a quarterly health review.
 *
 * Usage (from repo root):
 *   node .github/skills/skill-health-report/scripts/generate-health-report.js
 *
 * Optional flags:
 *   --feedback-path <path>   override FEEDBACK.md location
 *   --catalog-path <path>    override CATALOG.md location
 *   --stale-days <n>         days since Last Audited before flagging overdue (default 100, ~1 quarter)
 */
const fs = require('fs');
const path = require('path');

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i += 2) {
    out[argv[i].replace(/^--/, '')] = argv[i + 1];
  }
  return out;
}
const args = parseArgs(process.argv.slice(2));
const feedbackPath = args['feedback-path'] || '.github/skills/FEEDBACK.md';
const catalogPath = args['catalog-path'] || '.github/skills/CATALOG.md';
const staleDays = parseInt(args['stale-days'] || '100', 10);

function parseMarkdownTable(content) {
  const lines = content.split('\n').filter((l) => l.trim().startsWith('|'));
  if (lines.length < 2) return [];
  const headers = lines[0]
    .split('|')
    .map((h) => h.trim())
    .filter(Boolean);
  const rows = [];
  for (const line of lines.slice(2)) {
    // skip the separator row (line[1], e.g. |---|---|)
    if (/^\|[\s-|]+\|$/.test(line)) continue;
    const cells = line
      .split('|')
      .map((c) => c.trim())
      .filter((c, i, arr) => !(i === 0 && c === '') && !(i === arr.length - 1 && c === ''));
    if (cells.length !== headers.length) continue;
    const row = {};
    headers.forEach((h, i) => (row[h] = cells[i]));
    rows.push(row);
  }
  return rows;
}

if (!fs.existsSync(feedbackPath)) {
  console.error(`Not found: ${feedbackPath}`);
  process.exit(1);
}
if (!fs.existsSync(catalogPath)) {
  console.error(`Not found: ${catalogPath}`);
  process.exit(1);
}

const feedbackRows = parseMarkdownTable(fs.readFileSync(feedbackPath, 'utf8'));
const catalogRows = parseMarkdownTable(fs.readFileSync(catalogPath, 'utf8'));

// --- Feedback pattern flags ---
const bySkill = {};
for (const row of feedbackRows) {
  const skill = row.Skill;
  if (!skill) continue;
  bySkill[skill] = bySkill[skill] || { 'missed-trigger': 0, 'false-trigger': 0, bug: 0, praise: 0, total: 0 };
  const type = (row.Type || '').toLowerCase();
  if (bySkill[skill][type] !== undefined) bySkill[skill][type]++;
  bySkill[skill].total++;
}

const feedbackFlags = [];
for (const [skill, counts] of Object.entries(bySkill)) {
  if (counts['missed-trigger'] >= 3) {
    feedbackFlags.push({ skill, flag: `${counts['missed-trigger']} missed-trigger reports — description likely needs rework` });
  }
  if (counts['false-trigger'] >= 3) {
    feedbackFlags.push({ skill, flag: `${counts['false-trigger']} false-trigger reports — description likely too broad or overlaps another skill` });
  }
  if (counts.bug >= 2) {
    feedbackFlags.push({ skill, flag: `${counts.bug} bug reports — instructions or bundled script likely need a fix` });
  }
}

// --- Catalog flags: overdue audits, stale deprecation ---
const catalogFlags = [];
const now = new Date();
for (const row of catalogRows) {
  const skill = row.Skill ? row.Skill.replace(/`/g, '') : null;
  if (!skill) continue;

  if (row['Last Audited'] && row['Last Audited'] !== '{{date}}') {
    const audited = new Date(row['Last Audited']);
    if (!isNaN(audited)) {
      const days = Math.floor((now - audited) / (1000 * 60 * 60 * 24));
      if (days > staleDays) {
        catalogFlags.push({ skill, flag: `Last audited ${days} days ago — overdue for re-audit (threshold ${staleDays}d)` });
      }
    }
  }

  if ((row.Status || '').toLowerCase() === 'deprecated') {
    catalogFlags.push({ skill, flag: 'Currently Deprecated — resolve to Active (new owner) or Retired this cycle, per MAINTENANCE.md' });
  }

  const skillNames = catalogRows.map((r) => r.Skill && r.Skill.replace(/`/g, '')).filter(Boolean);
  if (!bySkill[skill] && skillNames.includes(skill)) {
    catalogFlags.push({ skill, flag: 'No feedback entries this period — verify actual usage before assuming success (see references/health-review-process.md)' });
  }
}

// --- Report ---
console.log('=== Skill Health Report ===\n');

console.log(`Feedback log entries parsed: ${feedbackRows.length}`);
console.log(`Catalog skills parsed: ${catalogRows.length}\n`);

if (feedbackFlags.length) {
  console.log('Feedback-pattern flags:');
  feedbackFlags.forEach((f) => console.log(`  🔶 ${f.skill}: ${f.flag}`));
} else {
  console.log('Feedback-pattern flags: none');
}

console.log('');

if (catalogFlags.length) {
  console.log('Catalog-status flags:');
  catalogFlags.forEach((f) => console.log(`  🔶 ${f.skill}: ${f.flag}`));
} else {
  console.log('Catalog-status flags: none');
}

console.log(`\n${feedbackFlags.length + catalogFlags.length} total flag(s). None of these are automatic retirements — `);
console.log('work through references/health-review-process.md and fill in assets/health-review-template.md.');
