---
name: skill-health-report
description: >
  Generate a quarterly skill health report from FEEDBACK.md and
  CATALOG.md — flags skills with repeated missed/false triggers, overdue
  re-audits, or long-deprecated status as retirement candidates. Use when
  asked for a "skill health review", "quarterly skill review", "which
  skills should we retire", or "how are our Copilot skills doing".
argument-hint: "none required — reads FEEDBACK.md and CATALOG.md directly"
---

# Skill Health Report

## When to Use
- Quarterly, alongside the re-audit cadence in `MAINTENANCE.md`
- Any time someone asks which skills are underused, broken, or candidates
  for retirement
- Before a team retro on the skill catalog

## Quick Start
```bash
node .github/skills/skill-health-report/scripts/generate-health-report.js
```
Run from the repo root — it expects `.github/skills/FEEDBACK.md` and
`.github/skills/CATALOG.md` to exist at their standard paths.

## Instructions

1. **Run the script first.** It does the counting/flagging mechanically —
   don't hand-tally the feedback log.
2. **Load `references/health-review-process.md`** for how to turn the raw
   flags into actual decisions (retire vs. fix vs. leave alone).
3. **Use `assets/health-review-template.md`** to write up the quarter's
   review — every quarter produces a filled-in template, not just a raw
   script dump, so decisions and reasoning are recorded, not just numbers.
4. **A skill flagged by the script is a candidate for discussion, not an
   automatic retirement.** Low feedback volume can mean "nobody uses it"
   or "it works so well nobody has anything to report" — the script can't
   tell those apart; a human has to.
5. After the review, update `CATALOG.md` statuses and, per
   `MAINTENANCE.md`, archive old `FEEDBACK.md` entries that were part of
   this cycle's review (keep a dated summary line, not every raw row
   forever).

## Output
A generated flag list from the script, turned into a completed
`health-review-template.md` with explicit decisions per flagged skill and
updated `CATALOG.md` statuses.
