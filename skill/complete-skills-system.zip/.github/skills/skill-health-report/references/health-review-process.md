# Health Review Process Reference

The script produces flags. This is how a human turns flags into decisions.

## Reading Missed/False Trigger Flags
- **3+ missed-trigger reports on the same skill in a quarter** — the
  description likely needs rework, not the skill's logic. Treat as a
  PATCH/MINOR fix per `MAINTENANCE.md`, re-test against the missed
  scenarios, don't just tweak and hope.
- **3+ false-trigger reports** — the description is too broad or overlaps
  another skill. Check `CATALOG.md` for a near-duplicate before assuming
  it just needs narrowing.
- **A skill with zero feedback entries for a full quarter** — ambiguous by
  itself (see SKILL.md point 4). Cross-check: has anyone actually invoked
  it? If no one on the team recalls using it, it's a retirement candidate
  regardless of whether anyone filed a complaint — silence isn't
  necessarily success.

## Reading Overdue-Audit Flags
An overdue re-audit (per `MAINTENANCE.md`'s quarterly cadence) is not
itself a quality problem — it's a process gap. Run the audit as part of
this review rather than just noting it's late.

## Reading Deprecated-Too-Long Flags
A skill `Deprecated` for more than one full quarter with no retirement
decision is a sign ownership has lapsed. Resolve one of two ways:
1. Retire it now (update `CATALOG.md`, delete the folder)
2. Someone explicitly recommits to it as owner and it returns to `Active`
No skill should sit in `Deprecated` indefinitely — that's a worse state
than either Active or Retired because it's still discoverable but
untrustworthy.

## When NOT to Retire
- A skill with negative feedback but a clear, fixable root cause (bad
  description, missing reference) should be fixed, not retired — retirement
  is for skills that are duplicated, obsolete (the underlying workflow
  changed), or genuinely unused.
- Don't retire based on one quarter of low usage alone if the underlying
  task it covers is seasonal or infrequent by nature (e.g. a skill for an
  annual process).
