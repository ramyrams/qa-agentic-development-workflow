# Skill Health Review — {{quarter}} {{year}}

**Reviewers:** {{names}}
**Date:** {{date}}
**Report generated from:** `generate-health-report.js` output on {{date}}

## Summary Flags (from script)
Paste the script's raw output here for the record.

```
{{script-output}}
```

## Decisions

| Skill | Flag(s) | Decision | Reasoning | Owner Action |
|---|---|---|---|---|
| | | Fix / Retire / Keep as-is / Reclaim ownership | | |

## Skills Retired This Quarter
| Skill | Reason | Superseded By (if any) |
|---|---|---|

## Skills With Ownership Gaps
| Skill | Current Status | New Owner (or "unclaimed — flagged for removal next cycle") |
|---|---|---|

## Feedback Log Maintenance
- [ ] `FEEDBACK.md` entries older than this cycle archived into a one-line
      dated summary per `MAINTENANCE.md`
- [ ] `CATALOG.md` statuses and `Last Audited` dates updated to match
      decisions above

## Notes for Next Quarter
Anything that came up in discussion worth revisiting even though it didn't
warrant action this cycle.
