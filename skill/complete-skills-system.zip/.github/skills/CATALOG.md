# Skills Catalog

The single source of truth for every skill in `.github/skills/`. A skill
that isn't listed here isn't considered part of the sanctioned catalog —
this is how we avoid sprawl (unmaintained, duplicate, or undiscoverable
skills accumulating in the folder with no one accountable for them).

**Rule:** no skill merges to this repo's `.github/skills/` without a row
here. Adding the row is part of the PR, not a follow-up task.

| Skill | Owner | Version | Status | Last Audited | Governance Flag |
|---|---|---|---|---|---|
| `add-rest-endpoint` | {{owner}} | 1.0.0 | Active | {{date}} | None — codegen only, no prod side effects |
| `pr-review` | {{owner}} | 1.0.0 | Active | {{date}} | None — advisory only, makes no changes |
| `audit-skill-quality` | {{owner}} | 1.0.0 | Active | {{date}} | None — read-only analysis |

## Column Definitions
- **Owner** — the person (not team) accountable for this skill. See
  `MAINTENANCE.md` for what ownership means in practice.
- **Version** — semantic version per `MAINTENANCE.md`'s scheme. Bump on
  every merged change to the skill.
- **Status** — `Active`, `Deprecated` (still works, don't build on it), or
  `Retired` (removed; row kept for history with a removal date noted).
- **Last Audited** — date `audit-skill-quality` was last run against this
  skill. Anything older than the re-audit cadence in `MAINTENANCE.md` is
  overdue.
- **Governance Flag** — per `audit-skill-quality`'s governance check: does
  this skill write to production, call external APIs with side effects, or
  touch auth/security code? If yes, note the Governance Gate ticket/status
  here, not just "yes".

## Before Proposing a New Skill
Search this table first. A near-duplicate of an existing skill is a reason
to extend that skill (new reference doc, new script) rather than fork a
second one that will drift out of sync with the first.
