# Audit Criteria Reference

## Description Quality (most common failure point)
A good description names: the domain, what the skill does, and concrete
trigger phrases a user would actually type. Test: could a teammate who's
never seen this skill guess when to invoke it, from the description alone?
- ❌ "Helps with API stuff"
- ✅ "Scaffold a new REST API endpoint... Use when the user asks to 'add an
  endpoint', 'create a new API route'..."

## Single Responsibility
One skill should do one job well. Red flags:
- SKILL.md has more than ~3 top-level "when to use" scenarios that aren't
  closely related
- The skill's name is generic enough that you can't tell what it does
  ("helpers", "utils", "misc")
If a skill is trying to cover two unrelated jobs, split it — two
well-scoped skills beat one sprawling one.

## Correct Use of references/ vs assets/ vs scripts/
- `references/` — documentation Copilot reads for context (rules,
  conventions, background). If a "reference" file is actually step-by-step
  instructions, it probably belongs in SKILL.md itself or is evidence the
  skill is too complex for one SKILL.md.
- `assets/` — templates/boilerplate to copy and fill in, not executed.
- `scripts/` — executable code. If a "script" is just a documentation file
  with a `.js` extension, it's miscategorized.

## SKILL.md Length and Density
Keep under ~150 lines. If it's longer, check whether content should move to
`references/`. A bloated SKILL.md gets fully loaded into context on every
trigger — that's the cost of not using progressive disclosure correctly.

## Script Safety
Any bundled script must be:
- Non-interactive (no prompts waiting on stdin)
- Idempotent (safe to run twice)
- Scoped to files/paths passed as arguments, not hardcoded to one machine's
  layout

## Determinism (see ../../DETERMINISM-FRAMEWORK.md for full framework)
The script's determinism-lint pass catches vague qualifiers and missing
numbered steps mechanically. On top of that, judge:
- Is generation logic that *could* be a script instead written as a prose
  instruction? Push it down to Tier 1.
- Does every Tier 3 (open-judgment) step have something deterministic
  checking its output afterward?
- If the skill has a generator script, does it have golden-scenario tests
  in `tests/` — and have they actually been run against a deliberately
  broken template to confirm they catch regressions, not just that they
  pass on the happy path?

## Governance Tie-In
Skills that write to production systems, call external APIs with side
effects, or touch auth/security code should go through a Governance Gate
review before joining the shared catalog — flag these explicitly rather
than approving on structure alone.
