#!/usr/bin/env node
/**
 * Mechanical structural audit of a skill folder. Checks what can be
 * checked by parsing, not judgment — the qualitative checks live in
 * references/audit-criteria.md.
 *
 * Usage:
 *   node audit-skill.js .github/skills/<target-skill>
 */
const fs = require('fs');
const path = require('path');

const target = process.argv[2];
if (!target) {
  console.error('Usage: node audit-skill.js <skill-folder-path>');
  process.exit(1);
}
if (!fs.existsSync(target)) {
  console.error(`Not found: ${target}`);
  process.exit(1);
}

const findings = [];
const note = (severity, message) => findings.push({ severity, message });

// 1. SKILL.md exists
const skillMdPath = path.join(target, 'SKILL.md');
if (!fs.existsSync(skillMdPath)) {
  note('blocking', 'No SKILL.md found — every skill requires one.');
  report();
  process.exit(1);
}

const content = fs.readFileSync(skillMdPath, 'utf8');
const lines = content.split('\n');

// 2. Frontmatter present and has name + description
const fmMatch = content.match(/^---\n([\s\S]*?)\n---/);
if (!fmMatch) {
  note('blocking', 'No YAML frontmatter found at top of SKILL.md.');
} else {
  const fm = fmMatch[1];
  if (!/^name:\s*\S+/m.test(fm)) note('blocking', 'Frontmatter missing `name`.');
  if (!/^description:/m.test(fm)) note('blocking', 'Frontmatter missing `description`.');
  const descMatch = fm.match(/description:\s*>?-?\s*\n?([\s\S]*?)(\n\w+:|\n---|$)/);
  const descText = descMatch ? descMatch[1] : '';
  if (descText.length < 60) {
    note('blocking', 'Description looks too short to convey trigger phrases — expand it.');
  }
  if (!/use (this |when)/i.test(descText) && !/["']/.test(descText)) {
    note('suggestion', 'Description may not name concrete trigger phrases — verify manually.');
  }
}

// 3. Length check
if (lines.length > 150) {
  note(
    'suggestion',
    `SKILL.md is ${lines.length} lines — consider moving detail to references/ (target < 150).`
  );
}

// 4. Folder usage
const sub = (name) => path.join(target, name);
const hasReferences = fs.existsSync(sub('references'));
const hasAssets = fs.existsSync(sub('assets'));
const hasScripts = fs.existsSync(sub('scripts'));

if (!hasReferences && !hasAssets && !hasScripts) {
  note('nitpick', 'No bundled references/assets/scripts — fine for a simple skill, confirm intentional.');
}

// 5. Referenced files actually exist — scan SKILL.md for relative links
const linkPattern = /`(references|assets|scripts)\/[^`\s]+`/g;
let m;
while ((m = linkPattern.exec(content))) {
  const relPath = m[0].replace(/`/g, '');
  const fullPath = path.join(target, relPath);
  if (!fs.existsSync(fullPath)) {
    note('blocking', `SKILL.md references ${relPath} but that file does not exist.`);
  }
}

// 6. Scripts: non-interactive heuristic (readline/prompt usage)
if (hasScripts) {
  const scriptFiles = fs.readdirSync(sub('scripts'));
  for (const f of scriptFiles) {
    const fullPath = path.join(sub('scripts'), f);
    if (fs.statSync(fullPath).isFile()) {
      const sc = fs.readFileSync(fullPath, 'utf8');
      // Look for actual invocation, not just the word — avoids the
      // detector matching its own pattern source (a real gotcha: a naive
      // /prompt\(/ check flags any file that contains that regex literal,
      // including this checker itself).
      const interactivePatterns = [
        /require\(['"]readline['"]\)/,
        /readline\.createInterface\(/,
        /inquirer\.prompt\(/,
      ];
      if (interactivePatterns.some((p) => p.test(sc))) {
        note('blocking', `scripts/${f} appears interactive (readline/inquirer) — must run unattended.`);
      }
      if (!/process\.argv/.test(sc) && f.endsWith('.js')) {
        note('suggestion', `scripts/${f} doesn't read process.argv — confirm it isn't hardcoded to one machine's paths.`);
      }
    }
  }
}

// 7. Determinism lint — vague qualifiers and Tier-3-without-validator
// (see DETERMINISM-FRAMEWORK.md). Mechanical proxy only; a human still
// makes the final call, but this catches the cheap, common cases.
const instructionsMatch = content.match(/##\s*Instructions([\s\S]*?)(\n##\s|\n---|$)/i);
const instructionsText = instructionsMatch ? instructionsMatch[1] : '';

const vagueQualifiers = [
  'appropriate', 'as needed', 'generally', 'usually', 'seems best',
  'however seems useful', 'whatever seems', 'as appropriate', 'if needed',
  'typically', 'in most cases', 'use your judgment', 'however seems',
];
const foundVague = vagueQualifiers.filter((q) =>
  new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(instructionsText)
);
if (foundVague.length) {
  note(
    'suggestion',
    `Instructions contain vague qualifier(s) [${foundVague.join(', ')}] — replace with concrete rules ` +
      `or explicit examples (see DETERMINISM-FRAMEWORK.md).`
  );
}

const hasNumberedSteps = /\n\s*\d+\.\s/.test(instructionsText);
if (instructionsText.trim() && !hasNumberedSteps) {
  note(
    'suggestion',
    'Instructions section is not a numbered list — numbered steps are followed more literally than prose (see DETERMINISM-FRAMEWORK.md).'
  );
}

// Tier-3-without-validator heuristic: skill generates/creates/scaffolds
// files but has no script with "valid" or "check" or "audit" or "lint" in
// its name to gate the output.
const generatesContent = /\b(generate|scaffold|create a new|write a new)\b/i.test(content);
if (generatesContent) {
  const scriptFiles = hasScripts ? fs.readdirSync(sub('scripts')) : [];
  const hasValidator = scriptFiles.some((f) => /valid|check|audit|lint|verify/i.test(f));
  if (!hasValidator) {
    note(
      'suggestion',
      'Skill appears to generate/scaffold content but has no validator script (name containing valid/check/audit/lint) — ' +
        'Tier 3 generation should have a Tier 1 gate (see DETERMINISM-FRAMEWORK.md).'
    );
  }
}

// 8. Golden-scenario regression tests present when the skill has a generator script
const hasGeneratorScript = hasScripts && fs.readdirSync(sub('scripts')).some((f) => /generat|scaffold/i.test(f));
if (hasGeneratorScript && !fs.existsSync(sub('tests'))) {
  note(
    'nitpick',
    'Skill has a generator script but no tests/ folder — consider golden-scenario regression tests (see DETERMINISM-FRAMEWORK.md).'
  );
}

report();
process.exit(findings.some((f) => f.severity === 'blocking') ? 1 : 0);

function report() {
  if (!findings.length) {
    console.log(`✅ ${target} — no mechanical issues found. Proceed to references/audit-criteria.md for the qualitative pass.`);
    return;
  }
  const order = { blocking: 0, suggestion: 1, nitpick: 2 };
  const icon = { blocking: '🔴', suggestion: '🟡', nitpick: '⚪' };
  console.log(`Audit of ${target}:\n`);
  findings
    .sort((a, b) => order[a.severity] - order[b.severity])
    .forEach((f) => console.log(`  ${icon[f.severity]} [${f.severity}] ${f.message}`));
  console.log(`\n${findings.length} finding(s). Fill these into assets/audit-scorecard.md.`);
}
