# Skill Audit Scorecard

**Skill audited:** {{skill-name}}
**Audited by:** {{name}}
**Date:** {{date}}
**Competency level of author (for team grading use):** User / Author / Architect

| Category | Pass / Needs Work | Notes |
|---|---|---|
| Frontmatter complete (name, description, argument-hint if applicable) | | |
| Description names concrete trigger phrases | | |
| Single responsibility — one clear job | | |
| SKILL.md under ~150 lines | | |
| references/ used correctly (context, not instructions) | | |
| assets/ used correctly (templates, not logic) | | |
| scripts/ used correctly (executable, not docs) | | |
| Scripts are non-interactive and idempotent | | |
| Referenced files actually exist and paths are correct | | |
| Governance flag needed? (prod writes, external APIs, auth/security) | | |

## Verdict
- [ ] Ready to ship to shared catalog as-is
- [ ] Needs fixes (see notes above) before shipping
- [ ] Needs Governance Gate review before shipping

## Required Fixes (if any)
1.
2.

## Optional Improvements
1.
