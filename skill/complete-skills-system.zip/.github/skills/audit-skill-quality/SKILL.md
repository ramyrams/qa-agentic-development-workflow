---
name: audit-skill-quality
description: >
  Audit a GitHub Copilot skill (a .github/skills/<name>/ folder) for
  structural quality before it ships to the team — frontmatter completeness,
  description/trigger quality, SKILL.md length, correct use of references
  vs. assets vs. scripts, and whether scripts are safe to auto-run. Use when
  asked to "review this skill", "audit this skill before we ship it", or
  "is this skill ready for the team". This is the Architect-level gate in
  the skill competency ladder.
argument-hint: "Path to the skill folder to audit, e.g. .github/skills/my-skill"
---

# Audit Skill Quality

## When to Use
- Before merging a new skill to the shared `.github/skills/` catalog
- Periodic re-audit of existing skills (conventions drift; skills should be
  re-checked, not just checked once)
- Grading a team member's skill as part of the Author → Architect
  competency progression

## Quick Start
```bash
node .github/skills/audit-skill-quality/scripts/audit-skill.js .github/skills/<target-skill>
```
Treat the script's output as a first pass. Then apply
`references/audit-criteria.md` for the judgment calls the script can't make
(is the description actually specific enough to trigger correctly? is the
skill scoped to one job or trying to do too much?).

## Instructions

1. **Run the script first** — it checks the mechanical structural rules
   (frontmatter present, SKILL.md line count, folder naming, whether
   referenced files actually exist).
2. **Then apply `references/audit-criteria.md`** for the qualitative checks:
   description specificity, single-responsibility scope, whether
   `references/` content is truly reference material (not instructions that
   belong in SKILL.md).
3. **Score using `assets/audit-scorecard.md`** — every audit produces a
   filled-in scorecard, not just a verdict, so the author knows exactly what
   to fix.
4. **Do not approve a skill whose description doesn't name concrete trigger
   phrases** — a vague description is the single most common cause of a
   skill silently never firing.
5. If the skill bundles a script, confirm the script is idempotent and
   doesn't require interactive input — non-interactive is required for an
   agent to run it unattended.

## Output
A filled `audit-scorecard.md` with a pass/needs-work verdict per category
and specific, actionable fixes — not a bare score.
