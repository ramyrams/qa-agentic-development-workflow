# Determinism Framework

SKILL.md instructions are natural language fed to an LLM — they are never
fully deterministic. The goal of this framework isn't zero variance
(impossible); it's **bounded, caught variance**: know exactly where a
skill can drift, minimize how much of it is drift-prone, and always have
something deterministic checking the drift-prone parts before output
ships.

## The Three Tiers

Every step in a skill falls into one of these. When designing or auditing
a skill, classify each step and push as much as possible toward Tier 1.

### Tier 1 — Deterministic Script
Same input → same output, every time. No LLM interpretation involved once
invoked. This is `scripts/` doing actual work (templating, file generation,
validation, linting) rather than being "documentation with a .js
extension" (see `audit-skill-quality/references/audit-criteria.md`).

**Rule: if a step can be written as code, write it as code, not as an
instruction telling the LLM to do it.** `generate-scaffold.js` in
`add-rest-endpoint` exists specifically because "generate a route file
following the template" as a prose instruction would produce a differently
-shaped file every time; running a script that does string substitution
does not.

### Tier 2 — Template-Constrained Generation
The LLM fills specific placeholders in a fixed structure it did not
design. Variance is bounded to the placeholder content — the shape of the
output can't drift because the shape isn't up to the model.
`endpoint.template.ts`'s `{{Resource}}`/`{{action}}` placeholders are Tier
2: the model decides *what* goes in the TODO business-logic block, not
*how the file is organized*.

### Tier 3 — Open Judgment
The LLM decides structure, approach, or content with no template
constraining the shape. Necessary for genuinely judgment-heavy work
(reviewing code quality, deciding whether a design is sound) — but this is
where drift lives. **Every Tier 3 step must have a Tier 1 validator
checking its output before the result is considered done.** This is why
`pr-review`'s judgment calls are followed by `run-static-checks.js`, and
why `add-rest-endpoint`'s generation is followed by `validate-endpoint.js`
— the validator is the deterministic backstop for the non-deterministic
step.

## Writing Instructions to Minimize Drift Within a Tier

Even Tier 3 instructions vary in how much they invite drift. Rules for
SKILL.md `## Instructions` sections:

1. **Numbered steps, not prose paragraphs.** A numbered list is followed
   more literally than a paragraph of guidance — this is an instruction-
   following property of the model, not a stylistic preference.
2. **Ban vague qualifiers.** Words like "appropriate," "as needed,"
   "generally," "usually," "seems best," "however seems useful" are
   invitations to drift — they ask the model to make a judgment call where
   a concrete rule should exist instead. (This is the core flaw in the
   `db-helper` sample skill used in Kata 5 — "just help however seems
   useful" is a non-instruction.)
3. **State the negative, not just the positive.** "Use `ApiError`, never
   hand-build `res.status().json()` for errors" constrains more than "use
   `ApiError` for errors" alone — the explicit "never" closes off the
   alternative the model might otherwise reach for.
4. **Concrete examples beat abstract description.** A one-line code
   example anchors output shape more reliably than a paragraph describing
   the shape.
5. **One skill, one job.** A skill covering multiple unrelated
   responsibilities (see the `db-helper` kitchen-sink example) multiplies
   the surface area for drift — there's more for the model to
   misinterpret and less specific guidance per responsibility.

## Regression Protection: Golden Scenarios

A skill that worked correctly when authored can start drifting when its
SKILL.md or templates are edited (Kata 4's extension work) — without a
way to detect this, drift is invisible until someone downstream hits it.

**Convention:** any skill with Tier 1/2 generation should ship a
`tests/` folder with fixed input scenarios and a runner script that
regenerates output for each scenario and re-runs the skill's own
validation script against it. This is the same idea as unit tests for
code — it exists so an edit that silently increases variance gets caught
before it reaches `pr-review`'s feedback loop or a teammate's frustration
in `FEEDBACK.md`.

See `add-rest-endpoint/tests/` for a worked example.

## How This Connects to Existing System Pieces
- `audit-skill-quality` now includes a determinism-lint pass (see its
  `scripts/audit-skill.js`) that flags vague-qualifier language and
  Tier-3-without-a-validator patterns mechanically.
- `MAINTENANCE.md`'s versioning rules apply to drift fixes the same as any
  other change — tightening an instruction to remove a vague qualifier is
  a PATCH; adding a new validator script is a MINOR.
- `FEEDBACK.md`'s "bug" entries are the real-world signal that a Tier 3
  step drifted — a recurring pattern of bug reports on one skill is often
  a sign a step needs to move down a tier (more scripting, less open
  judgment) rather than just a wording tweak.
