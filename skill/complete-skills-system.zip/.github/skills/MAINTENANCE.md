# Skill Maintenance Conventions

Governs how skills in this catalog are versioned, owned, and retired. Read
this before modifying any existing skill or proposing a new one.

## Ownership
- Every skill has exactly one named owner in `CATALOG.md` — not a team.
  Shared ownership is how skills go stale silently.
- The owner is accountable for: responding to re-audit findings, approving
  changes to the skill, and deciding deprecation.
- Ownership transfers are a one-line PR updating `CATALOG.md` — don't let a
  skill go orphaned when someone changes teams. An orphaned skill (owner no
  longer on the team, row not updated) is treated as `Deprecated` until
  claimed.

## Versioning
Semantic-ish versioning, tracked in `CATALOG.md` (not in SKILL.md
frontmatter, to keep the frontmatter minimal):
- **MAJOR** — the skill's trigger behavior or core instructions change in a
  way that changes what it does or when it fires. Anyone who learned the old
  version should know something changed.
- **MINOR** — new `references/`, `assets/`, or `scripts/` added; existing
  behavior unchanged, capability extended.
- **PATCH** — bug fix in a script, typo/clarity fix in SKILL.md or
  references, no behavior change.

Bump the version in the same PR as the change. A change to a skill without
a version bump should be treated as a review-blocking omission.

## Re-Audit Cadence
- Re-run `audit-skill-quality` on every skill **quarterly**, or immediately
  after any MAJOR version bump.
- Update `Last Audited` in `CATALOG.md` after each run, whether or not
  findings resulted in changes.
- A skill more than one quarter overdue is flagged `Needs Re-Audit` in
  Status until cleared.

## Deprecation and Retirement
1. **Deprecated** — the skill still works but shouldn't be built on
   further (e.g. superseded by a better skill, or the underlying pattern
   changed). Note the replacement (if any) in the skill's SKILL.md
   description.
2. **Retired** — remove the skill folder. Keep the `CATALOG.md` row with
   status `Retired` and a removal date, so history isn't lost and no one
   re-proposes an already-tried-and-abandoned skill without knowing why it
   was retired.

## Governance Gate Interaction
`audit-skill-quality` flags skills touching production writes, external
APIs with side effects, or auth/security code. Any such flag means:
- The skill cannot move to `Active` status in `CATALOG.md` until it has
  been through the Governance Gate.
- Log the Gate ticket/decision in the `Governance Flag` column, not just a
  yes/no — future re-audits need to know what was actually reviewed and
  approved, not just that governance was "handled" at some point.
